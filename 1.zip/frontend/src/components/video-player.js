export const createVideoPlayer = (videoUrl) => {

  // ── 1. Detect YouTube ──────────────────────────────────────────────────────
  const extractYouTubeID = (url) => {
    if (!url) return null;
    const regExp = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]{11}).*/;
    const match = url.match(regExp);
    return match ? match[2] : null;
  };

  // ── 2. Detect Bunny.net embed URL ─────────────────────────────────────────
  // Accepts formats like:
  //   https://iframe.mediadelivery.net/embed/<libraryId>/<videoId>
  //   https://video.bunnycdn.com/...
  //   https://dash.bunny.net/...  (dashboard link → we convert it)
  const extractBunnyEmbed = (url) => {
    if (!url) return null;

    // Already a proper embed URL
    if (/iframe\.mediadelivery\.net\/embed/i.test(url)) return url;

    // video.bunnycdn.com embed
    if (/video\.bunnycdn\.com/i.test(url)) return url;

    // ✅ player.mediadelivery.net/play/<libId>/<videoId>  →  convert to embed
    // مثال: https://player.mediadelivery.net/play/767585/9924e97f-d146-4165-b29e-23279ad9ae0f
    const playerMatch = url.match(/player\.mediadelivery\.net\/play\/(\d+)\/([a-zA-Z0-9-]+)/i);
    if (playerMatch) {
      return `https://iframe.mediadelivery.net/embed/${playerMatch[1]}/${playerMatch[2]}?autoplay=false&loop=false&muted=false&preload=true`;
    }

    // dash.bunny.net/library/<libId>/videos/<videoId>  →  convert to embed
    const dashMatch = url.match(/dash\.bunny\.net\/library\/(\d+)\/videos\/([a-zA-Z0-9-]+)/i);
    if (dashMatch) {
      return `https://iframe.mediadelivery.net/embed/${dashMatch[1]}/${dashMatch[2]}?autoplay=false&loop=false&muted=false&preload=true`;
    }

    return null;
  };

  // ── 3. Render ─────────────────────────────────────────────────────────────
  const youtubeId  = extractYouTubeID(videoUrl);
  const bunnyEmbed = !youtubeId ? extractBunnyEmbed(videoUrl) : null;

  if (youtubeId) {
    const embedUrl = `https://www.youtube.com/embed/${youtubeId}?rel=0&modestbranding=1`;
    return `
      <div class="video-container">
        <iframe
          src="${embedUrl}"
          title="YouTube video player"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen>
        </iframe>
      </div>
    `;
  }

  if (bunnyEmbed) {
    return `
      <div class="video-container">
        <iframe
          src="${bunnyEmbed}"
          title="Bunny.net video player"
          frameborder="0"
          allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture"
          allowfullscreen
          style="border: none;">
        </iframe>
      </div>
    `;
  }

  // ── 4. Fallback ───────────────────────────────────────────────────────────
  return `
    <div class="video-container" style="background:#111;display:flex;align-items:center;justify-content:center;height:100%;min-height:300px;">
      <div style="text-align:center;color:var(--text-muted);">
        <i class="fas fa-video-slash" style="font-size:3rem;margin-bottom:15px;"></i>
        <p>الفيديو غير متوفر</p>
      </div>
    </div>
  `;
};

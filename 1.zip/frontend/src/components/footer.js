export const renderFooter = () => {
  const currentYear = new Date().getFullYear();
  
  return `
    <footer class="footer">
      <div class="container">
        <div class="grid grid-3">
          <div>
            <h3 class="nav-brand mb-4">
              <i class="fas fa-laptop-medical text-primary"></i>
              <span>InfoTex<span class="text-gradient">Academy</span></span>
            </h3>
            <p class="text-secondary">
              أكاديمية متخصصة في تعليم صيانة اللابتوبات من الصفر حتى الاحتراف مع أفضل الخبراء.
            </p>
            <div class="flex gap-4 mt-4" style="display:flex;gap:15px;margin-top:20px;">
              <a href="#" style="color:var(--text-muted);font-size:1.5rem;"><i class="fab fa-facebook"></i></a>
              <a href="#" style="color:var(--text-muted);font-size:1.5rem;"><i class="fab fa-youtube"></i></a>
              <a href="#" style="color:var(--text-muted);font-size:1.5rem;"><i class="fab fa-telegram"></i></a>
            </div>
          </div>
          
          <div>
            <h4 class="mb-4">روابط سريعة</h4>
            <ul style="display:flex;flex-direction:column;gap:10px;">
              <li><a href="#/" class="text-secondary hover:text-primary">الرئيسية</a></li>
              <li><a href="#/courses" class="text-secondary hover:text-primary">الكورسات</a></li>
              <li><a href="#/login" class="text-secondary hover:text-primary">تسجيل الدخول</a></li>
            </ul>
          </div>
          
          <div>
            <h4 class="mb-4">تواصل معنا</h4>
            <ul style="display:flex;flex-direction:column;gap:15px;">
              <li style="display:flex;align-items:center;gap:10px;color:var(--text-secondary);">
                <i class="fas fa-envelope text-primary"></i> <a href="mailto:infotexenna@gmail.com" style="color: inherit; text-decoration: none;">infotexenna@gmail.com</a>
              </li>
              <li style="display:flex;align-items:center;gap:10px;color:var(--text-secondary);">
                <i class="fas fa-phone text-primary"></i> <a href="https://wa.me/213553814639" style="color: inherit; text-decoration: none;" target="_blank">+213 553 81 46 39</a>
              </li>
              <li style="display:flex;align-items:center;gap:10px;color:var(--text-secondary);">
                <i class="fas fa-map-marker-alt text-primary"></i> أكاديمية أونلاين
              </li>
            </ul>
          </div>
        </div>
        
        <div style="text-align:center;margin-top:40px;padding-top:20px;border-top:1px solid var(--border);color:var(--text-muted);">
          &copy; ${currentYear} InfoTexAcademy. جميع الحقوق محفوظة.
        </div>
      </div>
    </footer>
  `;
};

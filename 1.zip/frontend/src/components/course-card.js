import { escapeHTML } from '../utils/helpers.js';

export const createCourseCard = (course, enrolled = false, progress = 0) => {
  const defaultThumb = 'data:image/svg+xml;charset=UTF-8,%3Csvg%20width%3D%22286%22%20height%3D%22180%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%20286%20180%22%20preserveAspectRatio%3D%22none%22%3E%3Cdefs%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E%23holder_18e11e03191%20text%20%7B%20fill%3A%23999%3Bfont-weight%3Anormal%3Bfont-family%3Avar(--font-family)%2C%20monospace%3Bfont-size%3A14pt%20%7D%20%3C%2Fstyle%3E%3C%2Fdefs%3E%3Cg%20id%3D%22holder_18e11e03191%22%3E%3Crect%20width%3D%22286%22%20height%3D%22180%22%20fill%3D%22%23373940%22%3E%3C%2Frect%3E%3Cg%3E%3Ctext%20x%3D%22108.5390625%22%20y%3D%2297.5%22%3E%D9%83%D9%88%D8%B1%D8%B3%3C%2Ftext%3E%3C%2Fg%3E%3C%2Fg%3E%3C%2Fsvg%3E';
  
  const id = course.id;
  const thumbnail = course.thumbnail_url || course.thumbnail || defaultThumb;
  const instructor = escapeHTML(course.instructor?.full_name || course.instructor?.name || 'المدرب');
  const level = course.level === 'beginner' ? 'مبتدئ' : (course.level === 'intermediate' ? 'متوسط' : (course.level === 'advanced' ? 'متقدم' : (course.level || 'مبتدئ')));
  const category = escapeHTML(course.category?.name_ar || course.category?.name || 'عام');
  const title = escapeHTML(course.title || '');
  
  let lessonsCount = 0;
  if (course.sections && Array.isArray(course.sections)) {
      lessonsCount = course.sections.reduce((acc, sec) => acc + (sec.lessons ? sec.lessons.length : 0), 0);
  }
  
  const price = course.price ? `$${course.price}` : 'مجاني';
  
  let levelClass = 'badge-primary';
  if (level === 'مبتدئ') levelClass = 'badge-success';
  if (level === 'متقدم') levelClass = 'badge-danger';
  if (level === 'متوسط') levelClass = 'badge-warning';

  const enrollBtn = enrolled 
    ? `<a href="#/courses/${id}" class="btn btn-outline" style="width:100%;margin-top:15px;">متابعة التعلم</a>`
    : `<a href="#/courses/${id}" class="btn btn-primary" style="width:100%;margin-top:15px;">عرض التفاصيل</a>`;
    
  const progressHTML = enrolled ? `
    <div class="progress-container">
      <div class="progress-bar" style="width: ${progress}%"></div>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:0.8rem;margin-top:5px;color:var(--text-muted);">
      <span>اكتمل</span>
      <span>${progress}%</span>
    </div>
  ` : '';

  const thumbContent = thumbnail 
    ? `<img src="${thumbnail}" alt="${title}" style="width:100%;height:100%;object-fit:cover;" />`
    : `<div class="course-thumb-bg"><i class="fas fa-laptop-code"></i></div>`;

  return `
    <div class="card course-card card-hover animate-slide-up">
      <div class="course-thumb">
        ${thumbContent}
        <div class="course-badges">
          <span class="badge ${levelClass}">${level}</span>
          <span class="badge badge-primary">${category}</span>
        </div>
      </div>
      
      <div class="course-content">
        <h3 class="course-title">${title}</h3>
        <p style="font-size:0.9rem;margin-bottom:15px;color:var(--text-secondary);">
          <i class="fas fa-chalkboard-teacher ml-1"></i> ${instructor}
        </p>
        
        <div class="course-meta">
          <span><i class="fas fa-book-open"></i> ${lessonsCount} درس</span>
          <span style="color: var(--success); font-weight: bold;"><i class="fas fa-tag"></i> ${price}</span>
        </div>
        
        ${progressHTML}
        ${enrollBtn}
      </div>
    </div>
  `;
};

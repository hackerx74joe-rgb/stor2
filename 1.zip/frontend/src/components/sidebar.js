export const createLessonSidebar = (course, progress = 0, currentLessonId = null) => {
  if (!course || !course.sections) return '';

  let sectionsHTML = '';
  
  course.sections.forEach((section, index) => {
    let lessonsHTML = '';
    let isSectionActive = false;
    
    section.lessons.forEach(lesson => {
      const isCurrent = lesson.id === currentLessonId;
      if (isCurrent) isSectionActive = true;
      const isCompleted = lesson.completed;
      
      lessonsHTML += `
        <a href="#/courses/${course.id}/lessons/${lesson.id}" 
           class="sidebar-lesson-item ${isCurrent ? 'active' : ''}"
           style="display:flex;justify-content:space-between;padding:12px 15px;color:var(--text-secondary);border-bottom:1px solid rgba(255,255,255,0.02);transition:all 0.2s;text-decoration:none;${isCurrent ? 'background:rgba(108,92,231,0.1);border-right:3px solid var(--primary);color:var(--text-primary);' : ''}">
          <div style="display:flex;align-items:center;gap:10px;">
            ${isCompleted 
              ? '<i class="fas fa-check-circle text-success"></i>' 
              : (isCurrent ? '<i class="fas fa-play-circle text-primary"></i>' : '<i class="far fa-circle text-muted"></i>')
            }
            <span style="font-size:0.9rem;${isCurrent ? 'font-weight:600;' : ''}">${lesson.title}</span>
          </div>
          <span style="font-size:0.75rem;color:var(--text-muted);">${lesson.duration || '0:00'}</span>
        </a>
      `;
    });

    sectionsHTML += `
      <div class="sidebar-section" style="border-bottom:1px solid var(--border);">
        <div class="sidebar-section-header" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'block' : 'none'" style="padding:15px;cursor:pointer;background:rgba(255,255,255,0.02);transition:background 0.2s;">
          <h4 style="margin:0;font-size:0.95rem;display:flex;justify-content:space-between;align-items:center;">
            ${section.title}
            <i class="fas fa-chevron-down" style="font-size:0.8rem;"></i>
          </h4>
        </div>
        <div class="sidebar-section-content" style="display: ${isSectionActive || index === 0 ? 'block' : 'none'};">
          ${lessonsHTML}
        </div>
      </div>
    `;
  });

  return `
    <div class="lesson-sidebar glass" style="height:100%;border-radius:var(--radius);overflow:hidden;display:flex;flex-direction:column;">
      <div style="padding:20px;border-bottom:1px solid var(--border);background:var(--bg-card);">
        <h3 style="font-size:1.1rem;margin-bottom:15px;">محتوى الكورس</h3>
        <div style="display:flex;justify-content:space-between;font-size:0.85rem;margin-bottom:8px;color:var(--text-secondary);">
          <span>نسبة الإنجاز</span>
          <span>${progress}%</span>
        </div>
        <div class="progress-container" style="height:8px;background:rgba(255,255,255,0.1);border-radius:4px;overflow:hidden;">
          <div class="progress-bar" style="width: ${progress}%;height:100%;background:var(--success);"></div>
        </div>
      </div>
      <div class="sidebar-sections-container" style="overflow-y:auto;flex-grow:1;">
        ${sectionsHTML}
      </div>
    </div>
  `;
};

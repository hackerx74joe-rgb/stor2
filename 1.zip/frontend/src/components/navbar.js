import { isAuthenticated, isAdmin, getUser, logout } from '../utils/auth.js';
import { escapeHTML } from '../utils/helpers.js';

export const renderNavbar = () => {
  const auth = isAuthenticated();
  const admin = isAdmin();
  const user = getUser();
  
  const currentHash = window.location.hash || '#/';
  
  const navLinks = `
    <a href="#/" class="nav-link ${currentHash === '#/' ? 'active' : ''}">الرئيسية</a>
    <a href="#/courses" class="nav-link ${currentHash.startsWith('#/courses') ? 'active' : ''}">الكورسات</a>
    ${auth ? `<a href="#/profile" class="nav-link ${currentHash === '#/profile' ? 'active' : ''}">كورساتي</a>` : ''}
    ${admin ? `<a href="#/admin" class="nav-link ${currentHash.startsWith('#/admin') ? 'active' : ''}">لوحة التحكم</a>` : ''}
  `;
  
  const displayName = escapeHTML(user?.full_name || user?.name || 'User');
  const username = user?.username ? `@${escapeHTML(user.username)}` : '';
  const initial = displayName.charAt(0).toUpperCase();

  const authSection = auth ? `
    <div class="user-dropdown">
      <div class="user-avatar">
        ${initial}
      </div>
      <div class="dropdown-menu">
        <div class="dropdown-item" style="cursor:default;border-bottom:1px solid var(--border);padding-bottom:10px;margin-bottom:5px;display:flex;flex-direction:column;align-items:start;gap:2px;">
          <small style="font-weight:bold;">${displayName}</small>
          ${username ? `<small class="text-muted" style="font-size:0.8rem;">${username}</small>` : ''}
        </div>
        <a href="#/profile" class="dropdown-item">
          <i class="fas fa-user"></i> الملف الشخصي
        </a>
        <div class="dropdown-divider"></div>
        <a href="#" id="logout-btn" class="dropdown-item text-danger">
          <i class="fas fa-sign-out-alt"></i> تسجيل خروج
        </a>
      </div>
    </div>
  ` : `
    <a href="#/login" class="btn btn-primary btn-sm">تسجيل الدخول</a>
  `;

  return `
    <nav class="navbar glass">
      <div class="container">
        <a href="#/" class="nav-brand">
          <i class="fas fa-laptop-medical text-primary"></i>
          <span>InfoTex<span class="text-gradient">Academy</span></span>
        </a>
        
        <div class="nav-links">
          ${navLinks}
        </div>
        
        <div class="nav-actions">
          ${authSection}
        </div>
        
        <button class="mobile-toggle" id="mobile-menu-btn">
          <i class="fas fa-bars"></i>
        </button>
      </div>
    </nav>
  `;
};

export const setupNavbar = () => {
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
    });
  }
  
  const mobileBtn = document.getElementById('mobile-menu-btn');
  const navbar = document.querySelector('.navbar');
  
  if (mobileBtn) {
    mobileBtn.addEventListener('click', () => {
      navbar.classList.toggle('mobile-menu-active');
    });
  }
};

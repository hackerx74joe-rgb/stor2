import './styles/main.css';
import { Router } from './utils/router.js';
import { requireAuth, requireAdmin, requireGuest } from './utils/auth.js';
import { renderNavbar, setupNavbar } from './components/navbar.js';
import { renderFooter } from './components/footer.js';

// Import pages
import { Home } from './pages/home.js';
import { Login } from './pages/login.js';
import { Courses } from './pages/courses.js';
import { CourseDetail } from './pages/course-detail.js';
import { Lesson } from './pages/lesson.js';
import { Profile } from './pages/profile.js';
import { AdminDashboard } from './pages/admin/dashboard.js';
import { ManageUsers } from './pages/admin/manage-users.js';
import { ManageCourses } from './pages/admin/manage-courses.js';

// Setup Toast System
const setupToast = () => {
  const container = document.createElement('div');
  container.id = 'toast-container';
  document.body.appendChild(container);

  window.showToast = (message, type = 'success') => {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    
    let icon = 'fa-check-circle';
    if (type === 'error') icon = 'fa-exclamation-circle';
    if (type === 'warning') icon = 'fa-exclamation-triangle';
    if (type === 'info') icon = 'fa-info-circle';
    
    toast.innerHTML = `
      <i class="fas ${icon}"></i>
      <span>${message}</span>
    `;
    
    container.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('hiding');
      setTimeout(() => toast.remove(), 300);
    }, 3000); // Wait 3s before hiding
  };
};

// Setup Confirm Dialog
window.showConfirm = (message) => {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay active';
    overlay.innerHTML = `
      <div class="modal card glass-strong text-center" style="max-width: 400px; padding: 30px;">
        <i class="fas fa-exclamation-triangle text-warning" style="font-size: 3rem; margin-bottom: 15px;"></i>
        <h3 style="margin-bottom: 20px;">تأكيد الإجراء</h3>
        <p style="margin-bottom: 25px; color: var(--text-secondary);">${message}</p>
        <div style="display: flex; gap: 15px; justify-content: center;">
          <button class="btn btn-outline" id="confirm-cancel">إلغاء</button>
          <button class="btn btn-danger" id="confirm-ok">تأكيد</button>
        </div>
      </div>
    `;
    
    document.body.appendChild(overlay);
    
    document.getElementById('confirm-cancel').onclick = () => {
      overlay.remove();
      resolve(false);
    };
    
    document.getElementById('confirm-ok').onclick = () => {
      overlay.remove();
      resolve(true);
    };
  });
};

const routes = [
  { path: '/', component: Home, setup: Home.setup },
  { path: '/login', component: Login, setup: Login.setup, guard: requireGuest },
  { path: '/courses', component: Courses, setup: Courses.setup },
  { path: '/courses/:id', component: CourseDetail, setup: CourseDetail.setup },
  { path: '/courses/:courseId/lessons/:lessonId', component: Lesson, setup: Lesson.setup, guard: requireAuth },
  { path: '/profile', component: Profile, setup: Profile.setup, guard: requireAuth },
  { path: '/admin', component: AdminDashboard, guard: requireAdmin },
  { path: '/admin/users', component: ManageUsers, setup: ManageUsers.setup, guard: requireAdmin },
  { path: '/admin/courses', component: ManageCourses, setup: ManageCourses.setup, guard: requireAdmin }
];

// Security Setup
const setupSecurity = () => {
  document.addEventListener('contextmenu', e => e.preventDefault());
  
  document.addEventListener('copy', e => {
      e.preventDefault();
      if(window.showToast) window.showToast('عذراً، النسخ غير مسموح به في هذه المنصة', 'warning');
  });
  
  document.addEventListener('keydown', e => {
      // Prevent F12, Ctrl+Shift+I, Ctrl+U, PrintScreen (if possible)
      if (
          e.key === 'F12' || 
          (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) || 
          (e.ctrlKey && (e.key === 'U' || e.key === 'u' || e.key === 'S' || e.key === 's' || e.key === 'P' || e.key === 'p' || e.key === 'A' || e.key === 'a')) || 
          e.key === 'PrintScreen' || 
          (e.metaKey && e.shiftKey && (e.key === 'S' || e.key === 's' || e.key === '3' || e.key === '4' || e.key === '5')) // Mac screenshot shortcuts
      ) {
          e.preventDefault();
      }
  });
};

const initApp = async () => {
  setupToast();
  setupSecurity();
  
  const appContainer = document.getElementById('app');
  
  // Wrap app in structure
  appContainer.outerHTML = `
    <div id="navbar-container"></div>
    <main id="app" style="margin-top: var(--header-height); min-height: calc(100vh - var(--header-height));"></main>
    <div id="footer-container"></div>
  `;
  
  // Initial render of navbar and footer
  const updateLayout = () => {
    const isLogin = window.location.hash === '#/login';
    const isAdmin = window.location.hash.startsWith('#/admin');
    
    const navContainer = document.getElementById('navbar-container');
    const footContainer = document.getElementById('footer-container');
    
    if (isLogin) {
      navContainer.innerHTML = '';
      footContainer.innerHTML = '';
      document.getElementById('app').style.marginTop = '0';
    } else if (isAdmin) {
      navContainer.innerHTML = renderNavbar();
      footContainer.innerHTML = ''; // Usually no footer in admin
      document.getElementById('app').style.marginTop = 'var(--header-height)';
      setupNavbar();
    } else {
      navContainer.innerHTML = renderNavbar();
      footContainer.innerHTML = renderFooter();
      document.getElementById('app').style.marginTop = 'var(--header-height)';
      setupNavbar();
    }
  };
  
  // Update layout on route change
  window.addEventListener('hashchange', updateLayout);
  updateLayout();
  
  // Initialize router
  const router = new Router(routes);
};

// Start
initApp();

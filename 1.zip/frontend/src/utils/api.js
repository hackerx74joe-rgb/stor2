import { getToken, removeToken, removeUser } from './auth.js';

const API_URL = '/api';

export async function fetchWrapper(endpoint, options = {}) {
  const token = getToken();
  
  const headers = {
    ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
    ...(options.headers || {})
  };

  // Only set application/json if we are not sending FormData
  if (!(options.body instanceof FormData) && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const config = {
    ...options,
    headers
  };

  try {
    const response = await fetch(`${API_URL}${endpoint}`, config);
    
    const data = await response.json().catch(() => ({}));

    // Only force logout if we HAD a token and the server says it's invalid/expired
    // Don't logout for endpoints that simply require auth when user isn't logged in
    if (response.status === 401 && token) {
      // Check if this is a token expiry/invalid issue vs just an unauthorized endpoint
      const errorMsg = data.error || '';
      if (errorMsg.includes('expired') || errorMsg.includes('Signature') || errorMsg.includes('access token')) {
        removeToken();
        removeUser();
        window.location.hash = '#/login';
        throw new Error('انتهت الجلسة، يرجى تسجيل الدخول مجدداً');
      }
    }

    if (!response.ok) {
      const error = new Error(data.error || data.message || 'حدث خطأ في الخادم');
      error.status = response.status;
      error.error = data.error || data.message || 'حدث خطأ في الخادم';
      throw error;
    }

    return data;
  } catch (error) {
    throw error;
  }
}

export const api = {
  get: (endpoint) => fetchWrapper(endpoint, { method: 'GET' }),
  post: (endpoint, body) => fetchWrapper(endpoint, { method: 'POST', body: body instanceof FormData ? body : JSON.stringify(body) }),
  put: (endpoint, body) => fetchWrapper(endpoint, { method: 'PUT', body: body instanceof FormData ? body : JSON.stringify(body) }),
  delete: (endpoint) => fetchWrapper(endpoint, { method: 'DELETE' })
};

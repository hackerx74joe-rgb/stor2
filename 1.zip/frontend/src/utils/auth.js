export const setToken = (token) => localStorage.setItem('token', token);
export const getToken = () => localStorage.getItem('token');
export const removeToken = () => localStorage.removeItem('token');

export const setUser = (user) => localStorage.setItem('user', JSON.stringify(user));
export const getUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};
export const removeUser = () => localStorage.removeItem('user');

export const isAuthenticated = () => !!getToken();
export const isAdmin = () => {
  const user = getUser();
  return user && user.role === 'admin';
};

export const logout = () => {
  removeToken();
  removeUser();
  window.location.hash = '#/login';
};

export const requireAuth = async () => {
  if (!isAuthenticated()) {
    window.location.hash = '#/login';
    return false;
  }
  return true;
};

export const requireAdmin = async () => {
  if (!isAuthenticated() || !isAdmin()) {
    window.location.hash = '#/';
    return false;
  }
  return true;
};

export const requireGuest = async () => {
  if (isAuthenticated()) {
    window.location.hash = '#/courses';
    return false;
  }
  return true;
};

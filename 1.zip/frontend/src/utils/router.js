export class Router {
  constructor(routes) {
    this.routes = routes;
    this.currentRoute = null;
    this.params = {};
    
    // Listen to hash changes
    window.addEventListener('hashchange', this.handleRouteChange.bind(this));
    // Initial load
    window.addEventListener('load', this.handleRouteChange.bind(this));
  }

  async handleRouteChange() {
    const hash = window.location.hash.slice(1) || '/';
    const path = hash.split('?')[0]; // simple split for query params if any
    
    const matchedRoute = this.matchRoute(path);
    
    if (matchedRoute) {
      // Run guards
      if (matchedRoute.guard) {
        const canAccess = await matchedRoute.guard();
        if (!canAccess) return;
      }
      
      this.currentRoute = matchedRoute;
      
      // Render
      const app = document.getElementById('app');
      app.innerHTML = '<div class="flex items-center justify-center h-screen"><div class="loading-spinner"></div></div>'; // simple loader
      
      try {
        const component = await matchedRoute.component();
        // Since we are returning HTML strings from pages
        app.innerHTML = component;
        
        // Setup event listeners after rendering
        if (matchedRoute.setup) {
          setTimeout(() => matchedRoute.setup(this.params), 0);
        }
        
        // Scroll to top
        window.scrollTo(0, 0);
      } catch (err) {
        console.error("Error rendering route:", err);
        app.innerHTML = '<div class="container text-center mt-20"><h2>حدث خطأ ما</h2><p>رجاء المحاولة لاحقاً</p></div>';
      }
    } else {
      // 404
      const app = document.getElementById('app');
      app.innerHTML = `
        <div class="container text-center" style="padding: 100px 0;">
          <h1 style="font-size: 5rem; margin-bottom: 20px;" class="text-gradient">404</h1>
          <h2>الصفحة غير موجودة</h2>
          <br/>
          <a href="#/" class="btn btn-primary">العودة للرئيسية</a>
        </div>
      `;
    }
  }

  matchRoute(path) {
    for (let route of this.routes) {
      const routeParts = route.path.split('/').filter(Boolean);
      const pathParts = path.split('/').filter(Boolean);
      
      if (routeParts.length === pathParts.length) {
        let match = true;
        this.params = {};
        
        for (let i = 0; i < routeParts.length; i++) {
          if (routeParts[i].startsWith(':')) {
            const paramName = routeParts[i].substring(1);
            this.params[paramName] = pathParts[i];
          } else if (routeParts[i] !== pathParts[i]) {
            match = false;
            break;
          }
        }
        
        if (match) return route;
      }
    }
    
    // Check exact match for root
    return this.routes.find(r => r.path === path);
  }

  navigate(path) {
    window.location.hash = path;
  }
}

export const navigate = (path) => {
  window.location.hash = path;
}

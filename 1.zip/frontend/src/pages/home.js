import { api } from '../utils/api.js';
import { isAuthenticated } from '../utils/auth.js';

export const Home = async () => {
  return `
    <div class="hero">
      <div class="hero-bg-shape shape-1"></div>
      <div class="hero-bg-shape shape-2"></div>
      
      <div class="container">
        <div class="grid grid-2" style="align-items:center;">
          <div class="animate-slide-up" style="animation-delay: 0.1s;">
            <h1 style="font-size: 3rem; margin-bottom: 20px;">
              أكاديمية <span class="text-gradient">InfoTex</span><br/>
              لتعليم صيانة اللابتوبات
            </h1>
            <p style="font-size: 1.1rem; margin-bottom: 30px; max-width: 500px;">
              تعلم صيانة اللابتوبات من الصفر حتى الاحتراف مع أفضل الكورسات المتخصصة. ابدأ رحلتك الآن في عالم الهاردوير والسوفتوير.
            </p>
            <div style="display: flex; gap: 15px;">
              <a href="#/courses" class="btn btn-primary btn-lg">تصفح الكورسات</a>
              ${!isAuthenticated() ? `<a href="#/login" class="btn btn-outline btn-lg">تسجيل الدخول</a>` : `<a href="#/profile" class="btn btn-outline btn-lg">حسابي</a>`}
            </div>
          </div>
          
          <div class="animate-fade-in" style="animation-delay: 0.3s; position: relative;">
            <div class="glass" style="border-radius: 50%; width: 100%; max-width: 400px; aspect-ratio: 1; display: flex; align-items: center; justify-content: center; margin: 0 auto; box-shadow: var(--glow-primary);">
              <i class="fas fa-laptop-medical text-primary" style="font-size: min(8rem, 30vw); animation: float 6s infinite alternate;"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <section style="padding: 60px 0; background: var(--bg-secondary);">
      <div class="container">
        <div class="grid grid-4 text-center">
          <div class="card glass-strong animate-slide-up">
            <i class="fas fa-video text-primary" style="font-size: 2.5rem; margin-bottom: 15px;"></i>
            <h3 id="stat-courses" style="font-size: 2rem; margin-bottom: 5px;" class="text-gradient">--</h3>
            <p style="margin: 0;">كورس متخصص</p>
          </div>
          <div class="card glass-strong animate-slide-up" style="animation-delay: 0.1s;">
            <i class="fas fa-users text-accent" style="font-size: 2.5rem; margin-bottom: 15px;"></i>
            <h3 id="stat-users" style="font-size: 2rem; margin-bottom: 5px;" class="text-accent-gradient">--</h3>
            <p style="margin: 0;">طالب مسجل</p>
          </div>
          <div class="card glass-strong animate-slide-up" style="animation-delay: 0.2s;">
            <i class="fas fa-book text-success" style="font-size: 2.5rem; margin-bottom: 15px;"></i>
            <h3 id="stat-lessons" style="font-size: 2rem; margin-bottom: 5px; color: var(--success);">--</h3>
            <p style="margin: 0;">درس تعليمي</p>
          </div>
          <div class="card glass-strong animate-slide-up" style="animation-delay: 0.3s;">
            <i class="fas fa-clock text-warning" style="font-size: 2.5rem; margin-bottom: 15px;"></i>
            <h3 id="stat-enrollments" style="font-size: 2rem; margin-bottom: 5px; color: var(--warning);">--</h3>
            <p style="margin: 0;">تسجيلات</p>
          </div>
        </div>
      </div>
    </section>

    <section style="padding: 80px 0;">
      <div class="container">
        <div style="text-align: center; margin-bottom: 50px;">
          <h2 class="text-gradient" style="display: inline-block;">الكورسات المميزة</h2>
          <p>اختر من بين أفضل كورسات صيانة اللابتوبات</p>
        </div>
        
        <div class="grid grid-3" id="featured-courses">
          ${Array(3).fill(0).map(() => `
            <div class="card skeleton" style="height: 350px;"></div>
          `).join('')}
        </div>
        
        <div style="text-align: center; margin-top: 40px;">
          <a href="#/courses" class="btn btn-outline">عرض كل الكورسات</a>
        </div>
      </div>
    </section>

    <section style="padding: 80px 0; background: var(--bg-secondary);">
      <div class="container">
        <div style="text-align: center; margin-bottom: 50px;">
          <h2>لماذا <span class="text-gradient">InfoTex Academy</span>؟</h2>
        </div>
        
        <div class="grid grid-3">
          <div class="card text-center card-hover">
            <div style="width: 60px; height: 60px; background: rgba(108, 92, 231, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
              <i class="fas fa-tools text-primary" style="font-size: 1.5rem;"></i>
            </div>
            <h4>محتوى عملي</h4>
            <p style="font-size: 0.9rem;">تطبيق عملي على أعطال حقيقية في بوردات اللابتوب</p>
          </div>
          
          <div class="card text-center card-hover">
            <div style="width: 60px; height: 60px; background: rgba(245, 158, 11, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
              <i class="fas fa-headset text-warning" style="font-size: 1.5rem;"></i>
            </div>
            <h4>دعم مستمر</h4>
            <p style="font-size: 0.9rem;">دعم فني وإجابة على استفساراتك طوال فترة الكورس</p>
          </div>
          
          <div class="card text-center card-hover">
            <div style="width: 60px; height: 60px; background: rgba(0, 210, 255, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
              <i class="fas fa-sync text-accent" style="font-size: 1.5rem;"></i>
            </div>
            <h4>تحديثات دورية</h4>
            <p style="font-size: 0.9rem;">تحديث مستمر للمحتوى لمواكبة أحدث التقنيات</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonials Section -->
    <section style="padding: 80px 0; background: var(--bg-card);">
      <div class="container">
        <div style="text-align: center; margin-bottom: 50px;">
          <h2>ماذا يقول <span class="text-gradient">طلابنا</span>؟</h2>
          <p>آراء حقيقية من متدربي InfoTex Academy</p>
        </div>
        
        <div class="grid grid-3" id="testimonials-container">
          <!-- Dynamically loaded -->
          ${Array(3).fill(0).map(() => `
            <div class="card skeleton" style="height: 200px;"></div>
          `).join('')}
        </div>
      </div>
    </section>
  `;
};

Home.setup = () => {
  // Load Testimonials
  api.get('/courses/featured-reviews').then(res => {
    if(res && res.data && res.data.length > 0) {
      document.getElementById('testimonials-container').innerHTML = res.data.map(r => `
        <div class="card glass-strong animate-slide-up" style="position: relative;">
          <div style="font-size: 2rem; color: rgba(108, 92, 231, 0.2); position: absolute; top: 15px; left: 15px;">
            <i class="fas fa-quote-left"></i>
          </div>
          <div style="display: flex; gap: 15px; align-items: center; margin-bottom: 15px;">
            <div style="width: 50px; height: 50px; border-radius: 50%; background: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 1.2rem; font-weight: bold; color: white;">
              ${r.user_name.charAt(0)}
            </div>
            <div>
              <h4 style="margin: 0;">${r.user_name}</h4>
              <div style="color: var(--warning); font-size: 0.9rem;">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</div>
            </div>
          </div>
          <p style="color: var(--text-secondary); font-style: italic;">"${r.comment || 'كورس ممتاز ومفيد جداً'}"</p>
        </div>
      `).join('');
    } else {
      document.getElementById('testimonials-container').innerHTML = '<div style="grid-column: span 3; text-align: center;" class="text-muted">لا توجد آراء حالياً</div>';
    }
  }).catch(e => console.error(e));
  import('../components/course-card.js').then(async ({ createCourseCard }) => {
    // Load Stats from public courses endpoint
    try {
      const coursesRes = await api.get('/courses/?per_page=1');
      const total = coursesRes?.data?.total || 0;
      document.getElementById('stat-courses').textContent = '+' + total;
    } catch (e) {}
    // Static promotional numbers for public display
    document.getElementById('stat-users').textContent = '+1000';
    document.getElementById('stat-lessons').textContent = '+500';
    document.getElementById('stat-enrollments').textContent = '+200';

    // Load Featured Courses
    const container = document.getElementById('featured-courses');
    try {
      const coursesResponse = await api.get('/courses/?per_page=3');
      if (coursesResponse && coursesResponse.data && coursesResponse.data.courses) {
        if(coursesResponse.data.courses.length > 0) {
            container.innerHTML = coursesResponse.data.courses.map(c => createCourseCard(c)).join('');
        } else {
            container.innerHTML = '<div style="grid-column: span 3; text-align: center;">لا توجد كورسات متاحة حالياً</div>';
        }
      } else {
        throw new Error('Invalid response');
      }
    } catch (error) {
      if (window.showToast) window.showToast('حدث خطأ أثناء تحميل الكورسات', 'error');
      container.innerHTML = '<div style="grid-column: span 3; text-align: center;">حدث خطأ في جلب الكورسات</div>';
    }
  });
};

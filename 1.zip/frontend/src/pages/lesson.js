import { createVideoPlayer } from '../components/video-player.js';
import { createLessonSidebar } from '../components/sidebar.js';
import { api } from '../utils/api.js';

export const Lesson = async () => {
  return `
    <div style="display: flex; height: calc(100vh - var(--header-height)); overflow: hidden;" id="lesson-layout">
      <!-- Main Content -->
      <div style="flex-grow: 1; display: flex; flex-direction: column; overflow-y: auto; background: var(--bg-primary);">
        
        <!-- Video Area -->
        <div style="background: #000; padding: 20px; flex-shrink: 0;" id="video-container">
          <div class="skeleton" style="width: 100%; aspect-ratio: 16/9; border-radius: var(--radius);"></div>
        </div>
        
        <!-- Lesson Info -->
        <div style="padding: 30px;">
          <div class="container" style="max-width: 900px; margin: 0;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
              <div>
                <h1 id="lesson-title" class="skeleton" style="font-size: 1.8rem; margin-bottom: 10px; width: 300px;">جاري التحميل...</h1>
                <p id="course-name" class="text-muted skeleton" style="width: 200px;">اسم الكورس</p>
              </div>
              <button id="mark-complete-btn" class="btn btn-outline" style="display:none;">
                <i class="fas fa-check-circle"></i> تحديد كمكتمل
              </button>
            </div>
            
            <div class="card glass">
              <h3 style="font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 15px;">وصف الدرس</h3>
              <p id="lesson-desc" class="text-secondary skeleton" style="line-height: 1.8; min-height: 60px;">
                جاري تحميل تفاصيل الدرس...
              </p>
            </div>
            
            <!-- Navigation -->
            <div style="display: flex; justify-content: space-between; margin-top: 30px; border-top: 1px solid var(--border); padding-top: 20px;">
              <button id="prev-lesson" class="btn btn-outline disabled" disabled><i class="fas fa-arrow-right ml-2"></i> الدرس السابق</button>
              <button id="next-lesson" class="btn btn-primary disabled" disabled>الدرس التالي <i class="fas fa-arrow-left mr-2"></i></button>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Sidebar toggle mobile -->
      <button id="toggle-sidebar-btn" class="btn btn-primary" style="position: fixed; bottom: 20px; left: 20px; z-index: 100; border-radius: 50%; width: 50px; height: 50px; display: none; align-items: center; justify-content: center; box-shadow: var(--glow-primary);">
        <i class="fas fa-list"></i>
      </button>

      <!-- Sidebar -->
      <div id="lesson-sidebar-container" style="width: 350px; border-right: 1px solid var(--border); background: var(--bg-card); flex-shrink: 0; transition: all 0.3s ease;">
        <div class="skeleton" style="width: 100%; height: 100%;"></div>
      </div>
    </div>
  `;
};

Lesson.setup = async (params) => {
  const { courseId, lessonId } = params;
  
  // Responsive layout
  const layout = document.getElementById('lesson-layout');
  const sidebar = document.getElementById('lesson-sidebar-container');
  const toggleBtn = document.getElementById('toggle-sidebar-btn');
  
  const checkWidth = () => {
    if (window.innerWidth < 992) {
      sidebar.style.position = 'fixed';
      sidebar.style.right = '-350px';
      sidebar.style.top = 'var(--header-height)';
      sidebar.style.height = 'calc(100vh - var(--header-height))';
      sidebar.style.zIndex = '90';
      toggleBtn.style.display = 'flex';
    } else {
      sidebar.style.position = 'relative';
      sidebar.style.right = '0';
      toggleBtn.style.display = 'none';
    }
  };
  
  window.addEventListener('resize', checkWidth);
  checkWidth();
  
  if (toggleBtn) {
    toggleBtn.addEventListener('click', () => {
      const currentRight = sidebar.style.right;
      sidebar.style.right = currentRight === '0px' ? '-350px' : '0px';
    });
  }
  
  try {
      const response = await api.get('/courses/' + courseId);
      if(response && response.data) {
          const course = response.data;
          
          let targetLesson = null;
          let flatLessons = [];
          
          if(course.sections) {
              course.sections.forEach(sec => {
                  if(sec.lessons) {
                      sec.lessons.forEach(l => {
                          flatLessons.push(l);
                          if(l.id == lessonId || (lessonId === '1' && flatLessons.length === 1)) {
                              targetLesson = l;
                          }
                      });
                  }
              });
          }
          
          if(!targetLesson && flatLessons.length > 0) {
              targetLesson = flatLessons[0];
          }

          if(!targetLesson) {
              document.getElementById('video-container').innerHTML = '<div style="color:white;text-align:center;padding:50px;">لا يوجد درس</div>';
              return;
          }
          
          let progressPercent = 0;
          try {
              const progRes = await api.get('/courses/' + courseId + '/progress');
              if(progRes && progRes.data) {
                  progressPercent = progRes.data.progress_percentage || 0;
              }
          } catch(e) {}
          
          document.getElementById('lesson-sidebar-container').innerHTML = createLessonSidebar(course, progressPercent, targetLesson.id);
          
          // Support YouTube and Bunny.net video URLs
          const videoUrl = targetLesson.youtube_url
            || targetLesson.youtube_embed_url
            || targetLesson.bunny_url
            || targetLesson.bunny_embed_url
            || targetLesson.video_url;

          if (videoUrl) {
              document.getElementById('video-container').innerHTML = createVideoPlayer(videoUrl);
          } else {
              document.getElementById('video-container').innerHTML = `
                <div style="color:white;text-align:center;padding:50px;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;">
                    <i class="fas fa-lock" style="font-size:3rem;margin-bottom:20px;color:var(--text-muted);"></i>
                    <h3>هذا الدرس مقفل</h3>
                    <p class="text-muted">يرجى التسجيل في الكورس أو تسجيل الدخول لمشاهدة هذا الدرس</p>
                    <a href="#/courses/${courseId}" class="btn btn-primary" style="margin-top:20px;">العودة لصفحة الكورس</a>
                </div>
              `;
          }
          
          const titleEl = document.getElementById('lesson-title');
          titleEl.textContent = targetLesson.title;
          titleEl.classList.remove('skeleton');
          
          const courseEl = document.getElementById('course-name');
          courseEl.textContent = course.title;
          courseEl.classList.remove('skeleton');
          
          const descEl = document.getElementById('lesson-desc');
          descEl.textContent = targetLesson.description || 'لا يوجد وصف';
          descEl.classList.remove('skeleton');
          
          const markBtn = document.getElementById('mark-complete-btn');
          markBtn.style.display = 'inline-block';
          markBtn.addEventListener('click', async () => {
              markBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
              try {
                  await api.put('/courses/lessons/' + targetLesson.id + '/complete', {});
                  markBtn.classList.remove('btn-outline');
                  markBtn.classList.add('btn-success');
                  markBtn.innerHTML = '<i class="fas fa-check-double"></i> مكتمل';
                  if (window.showToast) window.showToast('تم تحديد الدرس كمكتمل', 'success');
              } catch(err) {
                  markBtn.innerHTML = '<i class="fas fa-check-circle"></i> تحديد كمكتمل';
                  if (window.showToast) window.showToast(err.error || 'حدث خطأ', 'error');
              }
          });
          
          const currentIndex = flatLessons.findIndex(l => l.id == targetLesson.id);
          const prevBtn = document.getElementById('prev-lesson');
          const nextBtn = document.getElementById('next-lesson');
          
          if(currentIndex > 0) {
              prevBtn.classList.remove('disabled');
              prevBtn.disabled = false;
              prevBtn.onclick = () => window.location.hash = '#/courses/' + courseId + '/lessons/' + flatLessons[currentIndex - 1].id;
          }
          if(currentIndex < flatLessons.length - 1) {
              nextBtn.classList.remove('disabled');
              nextBtn.disabled = false;
              nextBtn.onclick = () => window.location.hash = '#/courses/' + courseId + '/lessons/' + flatLessons[currentIndex + 1].id;
          }
      }
  } catch(e) {
      console.error(e);
      if(window.showToast) window.showToast('حدث خطأ في جلب الدرس', 'error');
  }
};

import { api } from '../utils/api.js';
import { isAuthenticated, isAdmin } from '../utils/auth.js';

export const CourseDetail = async () => {
  return `
    <!-- Hero Banner -->
    <div style="background: linear-gradient(to right, #0a0a0f, #1a1a2e); border-bottom: 1px solid var(--border); padding: 60px 0;">
      <div class="container">
        <div class="layout-course-header" id="course-header-layout">
          <div>
            <div style="display: flex; gap: 10px; margin-bottom: 15px;" id="course-badges">
              <span class="badge skeleton" style="width: 60px;"></span>
              <span class="badge skeleton" style="width: 60px;"></span>
            </div>
            <h1 style="font-size: 2.5rem; margin-bottom: 20px;" id="course-title" class="skeleton">جاري التحميل...</h1>
            <p style="font-size: 1.1rem; color: var(--text-secondary); margin-bottom: 20px; line-height: 1.8;" id="course-desc" class="skeleton">
              جاري تحميل تفاصيل الكورس...
            </p>
            <div style="display: flex; gap: 20px; color: var(--text-muted);" id="course-meta">
              <span class="skeleton" style="width: 80px; height: 20px; display: inline-block;"></span>
              <span class="skeleton" style="width: 80px; height: 20px; display: inline-block;"></span>
              <span class="skeleton" style="width: 80px; height: 20px; display: inline-block;"></span>
            </div>
          </div>
          
          <div class="card glass-strong" style="padding: 20px; text-align: center;">
            <div style="aspect-ratio: 16/9; background: #111; border-radius: var(--radius); margin-bottom: 20px; display: flex; align-items: center; justify-content: center; overflow: hidden;" id="course-thumb">
              <i class="fas fa-laptop-code" style="font-size: 3rem; color: rgba(255,255,255,0.1);"></i>
            </div>
            <div id="enrollment-section">
                <h2 style="margin-bottom: 20px; color: var(--success);" id="course-price-display">جاري التحميل...</h2>
                <p style="margin-bottom: 10px; color: var(--text-muted); font-size: 0.9rem;">للاشتراك في الكورس، يرجى التواصل معنا عبر:</p>
                <div style="display: flex; flex-direction: column; gap: 10px;">
                  <a href="https://wa.me/213553814639" target="_blank" class="btn btn-success btn-lg" style="width: 100%; background: #25D366; border: none; color: white;">
                    <i class="fab fa-whatsapp"></i> تواصل عبر واتساب
                  </a>
                  <a href="mailto:infotexenna@gmail.com" class="btn btn-danger btn-lg" style="width: 100%; background: #EA4335; border: none; color: white;">
                    <i class="fas fa-envelope"></i> تواصل عبر البريد
                  </a>
                </div>
            </div>
            <p style="font-size: 0.8rem; color: var(--text-muted); margin-top: 15px;">
              <i class="fas fa-infinity"></i> وصول مدى الحياة للكورس
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Course Content -->
    <div class="container" style="padding: 60px 0;">
      <div class="layout-course-content" id="course-content-layout">
        <div>
          <h2 style="margin-bottom: 30px; border-bottom: 1px solid var(--border); padding-bottom: 10px;">محتوى الكورس</h2>
          
          <div id="course-sections">
            ${Array(3).fill(0).map(() => `
              <div class="card skeleton" style="height: 60px; margin-bottom: 15px;"></div>
            `).join('')}
          </div>

          <h2 style="margin-top: 50px; margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 10px;">تقييمات الكورس</h2>
          <div id="course-review-form" style="display: none; margin-bottom: 30px;">
            <div class="card glass">
              <h3 style="margin-bottom: 15px;">أضف تقييمك</h3>
              <form id="add-review-form">
                <div class="form-group">
                  <label class="form-label">التقييم (من 1 إلى 5)</label>
                  <select id="review-rating" class="form-control" required>
                    <option value="5">5 نجوم - ممتاز</option>
                    <option value="4">4 نجوم - جيد جداً</option>
                    <option value="3">3 نجوم - جيد</option>
                    <option value="2">نجمتان - مقبول</option>
                    <option value="1">نجمة واحدة - سيء</option>
                  </select>
                </div>
                <div class="form-group">
                  <label class="form-label">رأيك (اختياري)</label>
                  <textarea id="review-comment" class="form-control" rows="3" placeholder="ما رأيك في هذا الكورس؟"></textarea>
                </div>
                <button type="submit" class="btn btn-primary" id="btn-submit-review">إرسال التقييم</button>
              </form>
            </div>
          </div>
          
          <div id="course-reviews">
             <div class="card skeleton" style="height: 100px;"></div>
          </div>
        </div>
        
          <div class="card glass" id="what-you-will-learn-card" style="display: none;">
            <h3 style="font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 15px;">ماذا ستتعلم؟</h3>
            <ul id="what-you-will-learn-list" style="display: flex; flex-direction: column; gap: 15px; font-size: 0.9rem;">
            </ul>
          </div>
        </div>
      </div>
    </div>
  `;
};

CourseDetail.setup = async (params) => {
  const { id } = params;
  
  try {
    const response = await api.get('/courses/' + id);
    if(response && response.data) {
        const course = response.data;
        
        // Header
        const catName = course.category?.name_ar || 'عام';
        document.getElementById('course-badges').innerHTML = `
            <span class="badge badge-primary">${catName}</span>
            <span class="badge badge-success">${course.level || 'مبتدئ'}</span>
        `;
        
        document.getElementById('course-title').textContent = course.title || 'بدون عنوان';
        document.getElementById('course-title').classList.remove('skeleton');
        
        document.getElementById('course-desc').textContent = course.description || 'لا يوجد وصف متاح';
        document.getElementById('course-desc').classList.remove('skeleton');
        
        let lessonsCount = 0;
        if(course.sections) {
            course.sections.forEach(s => {
                if(s.lessons) lessonsCount += s.lessons.length;
            });
        }
        
        document.getElementById('course-meta').innerHTML = `
            <span><i class="fas fa-chalkboard-teacher text-primary"></i> ${'المدرب'}</span>
            <span><i class="fas fa-book-open text-primary"></i> ${lessonsCount} درس</span>
            ${course.duration_hours ? `<span><i class="fas fa-clock text-primary"></i> ${course.duration_hours} ساعة</span>` : ''}
        `;
        
        if (course.thumbnail_url || course.thumbnail) {
            document.getElementById('course-thumb').innerHTML = `<img src="${course.thumbnail_url || course.thumbnail}" alt="${course.title}" style="width: 100%; height: 100%; object-fit: cover;" />`;
        }

        // What you will learn
        if (course.what_you_will_learn && course.what_you_will_learn.trim() !== '') {
            const listCard = document.getElementById('what-you-will-learn-card');
            const ul = document.getElementById('what-you-will-learn-list');
            ul.innerHTML = '';
            
            const lines = course.what_you_will_learn.split('\\n').filter(line => line.trim() !== '');
            lines.forEach(line => {
                const li = document.createElement('li');
                li.style.display = 'flex';
                li.style.gap = '10px';
                li.innerHTML = `<i class="fas fa-check text-success" style="margin-top: 3px;"></i><span>${line.trim()}</span>`;
                ul.appendChild(li);
            });
            listCard.style.display = 'block';
        }

        // Enrollment
        let isEnrolled = false;
        if (isAuthenticated()) {
            if (isAdmin()) {
                isEnrolled = true;
            } else {
                try {
                    const myCourses = await api.get('/courses/my-courses');
                    if (myCourses && myCourses.data && myCourses.data.some(c => c.id == id)) {
                        isEnrolled = true;
                    }
                } catch(e) {}
            }
        }

        const enrollSection = document.getElementById('enrollment-section');
        const priceDisplay = course.price ? `$${course.price}` : 'مجاني بالكامل';

        if (isEnrolled) {
            enrollSection.innerHTML = `
                <h2 style="margin-bottom: 20px; color: var(--success);">أنت مسجل</h2>
                <a href="#/courses/${id}/lessons/1" class="btn btn-primary btn-lg" style="width: 100%; box-shadow: var(--glow-primary);">متابعة التعلم</a>
            `;
        } else {
            enrollSection.innerHTML = `
                <h2 style="margin-bottom: 20px; color: var(--success);">${priceDisplay}</h2>
                <p style="margin-bottom: 10px; color: var(--text-muted); font-size: 0.9rem;">للاشتراك في الكورس، يرجى التواصل معنا عبر:</p>
                <div style="display: flex; flex-direction: column; gap: 10px;">
                  <a href="https://wa.me/213553814639" target="_blank" class="btn btn-success btn-lg" style="width: 100%; background: #25D366; border: none; color: white;">
                    <i class="fab fa-whatsapp"></i> تواصل عبر واتساب
                  </a>
                  <a href="mailto:infotexenna@gmail.com" class="btn btn-danger btn-lg" style="width: 100%; background: #EA4335; border: none; color: white;">
                    <i class="fas fa-envelope"></i> تواصل عبر البريد
                  </a>
                </div>
            `;
        }
        
        // Sections
        if(course.sections && course.sections.length > 0) {
            let sectionsHtml = '';
            course.sections.forEach((sec, idx) => {
                const lessonsCount = sec.lessons ? sec.lessons.length : 0;
                sectionsHtml += `
                    <div class="card" style="padding: 0; margin-bottom: 15px;">
                        <div style="padding: 15px 20px; background: rgba(255,255,255,0.02); display: flex; justify-content: space-between; cursor: pointer; font-weight: 600;" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'block' : 'none'">
                            <span>${sec.title}</span>
                            <span>${lessonsCount} درس</span>
                        </div>
                        <div style="padding: 10px 20px; display: ${idx === 0 ? 'block' : 'none'};">
                `;
                
                if (sec.lessons) {
                    sec.lessons.forEach(l => {
                        sectionsHtml += `
                            <div style="display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid var(--border);">
                                <span>
                                    <i class="fas fa-play-circle text-primary ml-2"></i> 
                                    <a href="#/courses/${id}/lessons/${l.id}" style="color: inherit; text-decoration: none;">${l.title}</a>
                                </span>
                                <span class="text-muted" style="font-size: 0.85rem;">${l.duration_minutes ? l.duration_minutes + ' د' : ''}</span>
                            </div>
                        `;
                    });
                } else {
                    sectionsHtml += `<div class="text-muted" style="padding: 10px 0;">لا توجد دروس</div>`;
                }
                
                sectionsHtml += `</div></div>`;
            });
            document.getElementById('course-sections').innerHTML = sectionsHtml;
        } else {
            document.getElementById('course-sections').innerHTML = '<div class="card text-center">لا توجد دروس في هذا الكورس بعد</div>';
        }
        // Reviews Logic
        const loadReviews = async () => {
          try {
            const revRes = await api.get('/courses/' + id + '/reviews');
            if (revRes && revRes.data) {
              const reviewsContainer = document.getElementById('course-reviews');
              if (revRes.data.length === 0) {
                reviewsContainer.innerHTML = '<div class="card text-center text-muted">لا توجد تقييمات بعد. كن أول من يقيّم!</div>';
              } else {
                reviewsContainer.innerHTML = revRes.data.map(r => `
                  <div class="card" style="margin-bottom: 15px; position: relative;">
                    ${isAdmin() ? `<button onclick="window.deleteReview(${r.id})" style="position: absolute; left: 15px; top: 15px; background: none; border: none; color: var(--danger); cursor: pointer;"><i class="fas fa-trash-alt"></i></button>` : ''}
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                      <strong style="color: var(--primary);">${r.user_name}</strong>
                      <span style="color: var(--warning);">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</span>
                    </div>
                    <p style="margin: 0; color: var(--text-secondary); font-size: 0.9rem;">${r.comment || ''}</p>
                    <small style="color: var(--text-muted); font-size: 0.8rem; margin-top: 10px; display: block;">${new Date(r.created_at).toLocaleDateString('ar-DZ')}</small>
                  </div>
                `).join('');
              }
            }
          } catch(e) { console.error('Error loading reviews', e); }
        };
        
        window.deleteReview = async (reviewId) => {
          if (!confirm('هل أنت متأكد من حذف هذا التقييم؟')) return;
          try {
            await api.delete('/admin/reviews/' + reviewId);
            if(window.showToast) window.showToast('تم حذف التقييم', 'success');
            await loadReviews();
          } catch(err) {
            if(window.showToast) window.showToast(err.error || 'حدث خطأ', 'error');
          }
        };

        await loadReviews();

        if (isEnrolled) {
          document.getElementById('course-review-form').style.display = 'block';
          document.getElementById('add-review-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('btn-submit-review');
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الإرسال...';
            try {
              const rating = parseInt(document.getElementById('review-rating').value);
              const comment = document.getElementById('review-comment').value;
              await api.post('/courses/' + id + '/reviews', { rating, comment });
              if(window.showToast) window.showToast('تمت إضافة التقييم بنجاح', 'success');
              document.getElementById('add-review-form').reset();
              document.getElementById('course-review-form').style.display = 'none';
              await loadReviews();
            } catch(err) {
              if(window.showToast) window.showToast(err.error || 'حدث خطأ', 'error');
            } finally {
              btn.disabled = false;
              btn.innerHTML = 'إرسال التقييم';
            }
          });
        }
    }
  } catch(error) {
    console.error(error);
    if(window.showToast) window.showToast('حدث خطأ في تحميل الكورس', 'error');
    document.getElementById('course-title').textContent = 'خطأ';
    document.getElementById('course-desc').textContent = 'تعذر تحميل بيانات الكورس';
  }
};

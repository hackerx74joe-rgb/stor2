import { getUser, setUser } from '../utils/auth.js';
import { createCourseCard } from '../components/course-card.js';
import { api } from '../utils/api.js';
import { escapeHTML } from '../utils/helpers.js';

export const Profile = async () => {
  const user = getUser() || { name: 'طالب تجريبي', email: 'student@example.com' };
  
  const displayName = escapeHTML(user.full_name || user.name || '');
  const firstChar = displayName ? displayName.charAt(0) : 'U';
  
  return `
    <div style="background: var(--bg-secondary); padding: 40px 0; border-bottom: 1px solid var(--border);">
      <div class="container">
        <div style="display: flex; align-items: center; gap: 30px;">
          <div style="width: 120px; height: 120px; border-radius: 50%; background: var(--primary-gradient); display: flex; align-items: center; justify-content: center; font-size: 3rem; color: white; font-weight: bold; box-shadow: var(--glow-primary); flex-shrink: 0;" id="profile-avatar">
            ${firstChar}
          </div>
          <div>
            <h1 style="margin-bottom: 5px;" id="profile-name">${displayName}</h1>
            <p class="text-secondary" style="margin-bottom: 15px;" id="profile-email">${escapeHTML(user.email || '')}</p>
            <div style="display: flex; gap: 15px;">
              <span class="badge badge-primary"><i class="fas fa-book-open"></i> <span id="courses-count">0</span> كورسات</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="container" style="padding: 40px 0;">
      <div class="layout-profile" id="profile-layout">
        
        <!-- Main Content -->
        <div>
          <h2 style="margin-bottom: 30px; border-bottom: 1px solid var(--border); padding-bottom: 10px;">كورساتي الحالية</h2>
          
          <div class="grid grid-2" id="my-courses-grid">
            ${Array(2).fill(0).map(() => `<div class="card skeleton" style="height: 350px;"></div>`).join('')}
          </div>
        </div>
        
        <!-- Sidebar -->
        <div>
          <div class="card glass">
            <h3 style="font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 20px;">تعديل البيانات</h3>
            
            <form id="profile-form">
              <div class="form-group">
                <label class="form-label">الاسم الكامل</label>
                <input type="text" class="form-control" id="edit-name" value="${displayName}" required>
              </div>
              
              <div class="form-group">
                <label class="form-label">البريد الإلكتروني</label>
                <input type="email" class="form-control" id="edit-email" value="${escapeHTML(user.email || '')}" disabled style="opacity: 0.7;">
              </div>
              
              <button type="submit" id="btn-save-profile" class="btn btn-outline" style="width: 100%; margin-top: 10px;">حفظ التغييرات</button>
            </form>
            
            <h3 style="font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 20px; margin-top: 40px;">تغيير كلمة المرور</h3>
            
            <form id="password-form">
              <div class="form-group">
                <label class="form-label">كلمة المرور الحالية</label>
                <input type="password" class="form-control" id="current-password" required>
              </div>
              <div class="form-group">
                <label class="form-label">كلمة المرور الجديدة</label>
                <input type="password" class="form-control" id="new-password" required>
              </div>
              
              <button type="submit" id="btn-save-pwd" class="btn btn-danger" style="width: 100%; margin-top: 10px;">تحديث كلمة المرور</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  `;
};

Profile.setup = async () => {
  
  // Forms
  document.getElementById('profile-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btn-save-profile');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري الحفظ...';
    try {
        const full_name = document.getElementById('edit-name').value;
        const res = await api.put('/auth/profile', { full_name });
        
        let currentUser = getUser();
        if(currentUser) {
            currentUser.full_name = full_name;
            setUser(currentUser);
        }
        
        document.getElementById('profile-name').textContent = full_name;
        document.getElementById('profile-avatar').textContent = full_name.charAt(0);
        
        if (window.showToast) window.showToast('تم تحديث البيانات بنجاح', 'success');
    } catch(err) {
        if (window.showToast) window.showToast(err.error || 'حدث خطأ أثناء التحديث', 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = 'حفظ التغييرات';
    }
  });
  
  document.getElementById('password-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btn-save-pwd');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> جاري التحديث...';
    try {
        const current_password = document.getElementById('current-password').value;
        const password = document.getElementById('new-password').value;
        
        await api.put('/auth/profile', { current_password, password });
        if (window.showToast) window.showToast('تم تغيير كلمة المرور بنجاح', 'success');
        e.target.reset();
    } catch(err) {
        if (window.showToast) window.showToast(err.error || 'حدث خطأ أثناء التغيير', 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = 'تحديث كلمة المرور';
    }
  });
  
  try {
      const meRes = await api.get('/auth/me');
      if (meRes && meRes.data) {
          const u = meRes.data;
          document.getElementById('profile-name').textContent = u.full_name || u.username || '';
          document.getElementById('profile-email').textContent = u.email || '';
          document.getElementById('edit-name').value = u.full_name || u.username || '';
          document.getElementById('edit-email').value = u.email || '';
          document.getElementById('profile-avatar').textContent = (u.full_name || u.username || 'U').charAt(0);
          setUser(u);
      }
      
      const coursesRes = await api.get('/courses/my-courses');
      const container = document.getElementById('my-courses-grid');
      
      if(coursesRes && coursesRes.data) {
          document.getElementById('courses-count').textContent = coursesRes.data.length;
          
          if(coursesRes.data.length > 0) {
              let html = '';
              for (const c of coursesRes.data) {
                  let progress = 0;
                  try {
                      const pRes = await api.get('/courses/' + c.id + '/progress');
                      if (pRes && pRes.data) progress = pRes.data.progress_percentage || 0;
                  } catch(e) {}
                  html += createCourseCard(c, true, progress);
              }
              container.innerHTML = html;
          } else {
              container.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px;">لا توجد كورسات مسجلة</div>';
          }
      }
  } catch(e) {
      console.error(e);
      document.getElementById('my-courses-grid').innerHTML = '<div style="grid-column: 1 / -1; text-align: center; color: var(--danger);">حدث خطأ في تحميل البيانات</div>';
  }
};

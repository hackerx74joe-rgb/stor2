import { createCourseCard } from '../components/course-card.js';
import { api } from '../utils/api.js';

export const Courses = async () => {
  return `
    <div style="background: var(--bg-secondary); padding: 40px 0; border-bottom: 1px solid var(--border);">
      <div class="container text-center">
        <h1 class="text-gradient">تصفح الكورسات</h1>
        <p style="max-width: 600px; margin: 0 auto;">اكتشف أفضل الكورسات في مجال صيانة اللابتوبات وابدأ رحلة التعلم الآن.</p>
        
        <div style="margin-top: 30px; max-width: 600px; margin-left: auto; margin-right: auto; position: relative;">
          <input type="text" id="course-search" class="form-control glass-strong" placeholder="ابحث عن كورس..." style="padding-right: 45px; border-radius: var(--radius-xl);">
          <i class="fas fa-search text-muted" style="position: absolute; right: 15px; top: 50%; transform: translateY(-50%);"></i>
        </div>
      </div>
    </div>
    
    <!-- Courses Content -->
    <div class="container" style="padding: 40px 0;">
      <div class="layout-courses" id="courses-layout">
        <!-- Sidebar filters -->
        <div class="glass" style="padding: 20px; border-radius: var(--radius); align-self: start;">
          <h3 style="font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 15px;">الفئات</h3>
          <ul id="categories-filter" style="display: flex; flex-direction: column; gap: 10px;">
            <li>جاري التحميل...</li>
          </ul>
          
          <h3 style="font-size: 1.1rem; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 15px; margin-top: 30px;">المستوى</h3>
          <ul id="levels-filter" style="display: flex; flex-direction: column; gap: 10px;">
            <li><label style="cursor: pointer; display: flex; gap: 10px;"><input type="radio" name="level_filter" value="مبتدئ" class="level-cb"> مبتدئ</label></li>
            <li><label style="cursor: pointer; display: flex; gap: 10px;"><input type="radio" name="level_filter" value="متوسط" class="level-cb"> متوسط</label></li>
            <li><label style="cursor: pointer; display: flex; gap: 10px;"><input type="radio" name="level_filter" value="متقدم" class="level-cb"> متقدم</label></li>
            <li><label style="cursor: pointer; display: flex; gap: 10px;"><input type="radio" name="level_filter" value="" class="level-cb" checked> الكل</label></li>
          </ul>
          
          <button id="apply-filters-btn" class="btn btn-outline" style="width: 100%; margin-top: 20px;">تطبيق الفلاتر</button>
        </div>
        
        <!-- Courses Grid -->
        <div>
          <div class="grid grid-2" id="courses-grid">
            ${Array(6).fill(0).map(() => `<div class="card skeleton" style="height: 350px;"></div>`).join('')}
          </div>
          
          <!-- Pagination -->
          <div id="pagination" style="display: flex; justify-content: center; margin-top: 40px; gap: 5px;">
          </div>
        </div>
      </div>
    </div>
  `;
};

Courses.setup = () => {
  
  let currentPage = 1;
  let currentSearch = '';
  let selectedCategory = '';
  let selectedLevel = '';

  const loadCategories = async () => {
    try {
      const res = await api.get('/courses/categories');
      if(res && res.data) {
        const catContainer = document.getElementById('categories-filter');
        catContainer.innerHTML = res.data.map(c => `
          <li><label style="cursor: pointer; display: flex; gap: 10px;">
            <input type="radio" name="category_filter" value="${c.id}" class="category-radio"> ${c.name_ar}
          </label></li>
        `).join('') + `
          <li><label style="cursor: pointer; display: flex; gap: 10px;">
            <input type="radio" name="category_filter" value="" class="category-radio" checked> الكل
          </label></li>
        `;
      }
    } catch(e) {
      console.error(e);
      document.getElementById('categories-filter').innerHTML = '<li>تعذر تحميل الفئات</li>';
    }
  };

  const loadCourses = async () => {
    const container = document.getElementById('courses-grid');
    container.innerHTML = Array(6).fill(0).map(() => `<div class="card skeleton" style="height: 350px;"></div>`).join('');
    
    try {
      const qs = new URLSearchParams();
      if(currentSearch) qs.append('search', currentSearch);
      if(selectedCategory) qs.append('category', selectedCategory);
      if(selectedLevel) qs.append('level', selectedLevel);
      qs.append('page', currentPage);
      qs.append('per_page', 12);

      const res = await api.get('/courses/?' + qs.toString());
      if(res && res.data && res.data.courses) {
        if(res.data.courses.length > 0) {
            container.innerHTML = res.data.courses.map(c => createCourseCard(c)).join('');
        } else {
            container.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px;">لا توجد كورسات مطابقة للبحث</div>';
        }
        
        // Render pagination
        const pages = res.data.pages || 1;
        const current = res.data.current_page || 1;
        const pagContainer = document.getElementById('pagination');
        
        let pagHtml = '';
        pagHtml += `<button class="btn btn-outline btn-sm ${current <= 1 ? 'disabled' : ''}" ${current <= 1 ? 'disabled' : ''} data-page="${current - 1}">السابق</button>`;
        for(let i=1; i<=pages; i++) {
            pagHtml += `<button class="btn ${i === current ? 'btn-primary' : 'btn-outline'} btn-sm" data-page="${i}">${i}</button>`;
        }
        pagHtml += `<button class="btn btn-outline btn-sm ${current >= pages ? 'disabled' : ''}" ${current >= pages ? 'disabled' : ''} data-page="${current + 1}">التالي</button>`;
        
        pagContainer.innerHTML = pagHtml;
        
        pagContainer.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                if(btn.disabled || btn.classList.contains('disabled')) return;
                currentPage = parseInt(btn.getAttribute('data-page'));
                loadCourses();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        });
      }
    } catch(e) {
      console.error(e);
      container.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; color: var(--danger);">حدث خطأ في تحميل الكورسات</div>';
      if(window.showToast) window.showToast('فشل تحميل الكورسات', 'error');
    }
  };

  // Search debounce
  let searchTimeout;
  const searchInput = document.getElementById('course-search');
  if(searchInput) {
      searchInput.addEventListener('input', (e) => {
          clearTimeout(searchTimeout);
          searchTimeout = setTimeout(() => {
              currentSearch = e.target.value;
              currentPage = 1;
              loadCourses();
          }, 500);
      });
  }
  
  const applyBtn = document.getElementById('apply-filters-btn');
  if(applyBtn) {
      applyBtn.addEventListener('click', () => {
          const checkedCat = document.querySelector('.category-radio:checked');
          selectedCategory = checkedCat ? checkedCat.value : '';
          
          const checkedLevel = document.querySelector('.level-cb:checked');
          selectedLevel = checkedLevel ? checkedLevel.value : '';
          
          currentPage = 1;
          loadCourses();
      });
  }

  loadCategories();
  loadCourses();
};

import { setToken, setUser, getUser } from '../utils/auth.js';
import { api } from '../utils/api.js';

export const Login = async () => {
  return `
    <div class="login-page">
      <div class="hero-bg-shape shape-1" style="top: 10%; right: 10%;"></div>
      <div class="hero-bg-shape shape-2" style="bottom: 10%; left: 10%;"></div>
      
      <div class="card glass-strong login-card animate-slide-up">
        <div style="text-align: center; margin-bottom: 30px;">
          <h2 class="nav-brand" style="justify-content: center;">
            <i class="fas fa-laptop-medical text-primary"></i>
            <span>InfoTex<span class="text-gradient">Academy</span></span>
          </h2>
          <p style="color: var(--text-secondary); margin-top: 10px;">تسجيل الدخول للمنصة التعليمية</p>
        </div>
        
        <div id="login-error" class="alert alert-danger" style="display: none; margin-bottom: 20px; padding: 12px; background: rgba(239, 68, 68, 0.1); border-left: 4px solid var(--danger); border-radius: 4px; color: var(--danger);"></div>
        
        <form id="login-form">
          <div class="form-group">
            <label class="form-label">البريد الإلكتروني / اسم المستخدم</label>
            <div class="input-with-icon">
              <input type="text" class="form-control" id="username" placeholder="أدخل اسم المستخدم" required>
              <i class="fas fa-user"></i>
            </div>
          </div>
          
          <div class="form-group">
            <label class="form-label">كلمة المرور</label>
            <div class="input-with-icon">
              <input type="password" class="form-control" id="password" placeholder="أدخل كلمة المرور" required>
              <i class="fas fa-lock" style="cursor:pointer;" id="toggle-password"></i>
            </div>
          </div>
          
          <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;" id="login-btn">
            تسجيل الدخول <i class="fas fa-sign-in-alt mr-2"></i>
          </button>
        </form>
        
        <div style="margin-top: 30px; text-align: center; padding-top: 20px; border-top: 1px solid var(--border);">
          <div style="display: inline-flex; align-items: center; gap: 10px; color: var(--warning); background: rgba(245, 158, 11, 0.1); padding: 10px 15px; border-radius: var(--radius); font-size: 0.9rem;">
            <i class="fas fa-exclamation-triangle"></i>
            هذه المنصة خاصة - يتم إنشاء الحسابات بواسطة الإدارة
          </div>
        </div>
      </div>
    </div>
  `;
};

Login.setup = () => {
  const form = document.getElementById('login-form');
  const errorDiv = document.getElementById('login-error');
  const loginBtn = document.getElementById('login-btn');
  const togglePassword = document.getElementById('toggle-password');
  const passwordInput = document.getElementById('password');
  
  if (togglePassword && passwordInput) {
    togglePassword.addEventListener('click', () => {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      togglePassword.classList.toggle('fa-eye');
      togglePassword.classList.toggle('fa-eye-slash');
    });
  }
  
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const username = document.getElementById('username').value;
      const password = passwordInput.value;
      
      if (!username || !password) return;
      
      loginBtn.classList.add('loading');
      errorDiv.style.display = 'none';
      
      try {
        const response = await api.post('/auth/login', { username, password });
        
        if (response.data && response.data.token && response.data.user) {
          setToken(response.data.token);
          setUser(response.data.user);
          
          if (window.showToast) window.showToast('تم تسجيل الدخول بنجاح', 'success');
          
          if (response.data.user.role === 'admin') {
            window.location.hash = '#/admin';
          } else {
            window.location.hash = '#/';
          }
        } else {
            throw new Error('فشل تسجيل الدخول');
        }
      } catch (error) {
        errorDiv.textContent = error.error || error.message || 'حدث خطأ أثناء تسجيل الدخول';
        errorDiv.style.display = 'block';
        errorDiv.classList.add('animate-slide-up');
        if (window.showToast) window.showToast('خطأ في تسجيل الدخول', 'error');
      } finally {
        loginBtn.classList.remove('loading');
      }
    });
  }
};

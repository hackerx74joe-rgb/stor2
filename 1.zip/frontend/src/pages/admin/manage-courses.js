import { api } from '../../utils/api.js';
import { getUser } from '../../utils/auth.js';

export const ManageCourses = async () => {
  return `
    <div class="admin-layout">
      <!-- Admin Sidebar -->
      <div class="admin-sidebar" id="admin-sidebar">
        <div style="padding: 0 20px 20px; border-bottom: 1px solid var(--border); margin-bottom: 20px;">
          <h3 class="text-gradient" style="margin: 0;">لوحة الإدارة</h3>
        </div>
        
        <nav style="display: flex; flex-direction: column;">
          <a href="#/admin" class="admin-nav-item">
            <i class="fas fa-home"></i> الرئيسية
          </a>
          <a href="#/admin/users" class="admin-nav-item">
            <i class="fas fa-users"></i> إدارة المستخدمين
          </a>
          <a href="#/admin/courses" class="admin-nav-item active">
            <i class="fas fa-video"></i> إدارة الكورسات
          </a>
          <a href="#/" class="admin-nav-item text-muted" style="margin-top: 20px; border-top: 1px solid var(--border); padding-top: 20px;">
            <i class="fas fa-external-link-alt"></i> العودة للموقع
          </a>
        </nav>
      </div>
      
      <!-- Admin Content -->
      <div class="admin-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
          <h2>إدارة الكورسات</h2>
          <button class="btn btn-primary" id="btn-open-add-course">
            <i class="fas fa-plus"></i> إضافة كورس جديد
          </button>
        </div>
        
        <div class="card glass" style="margin-bottom: 30px;">
          <div class="table-container">
            <table class="table" id="courses-table">
              <thead>
                <tr>
                  <th>الكورس</th>
                  <th>الفئة</th>
                  <th>المستوى</th>
                  <th>الدروس</th>
                  <th>الحالة</th>
                  <th>إجراءات</th>
                </tr>
              </thead>
              <tbody id="courses-tbody">
                <tr><td colspan="6" class="text-center">جاري التحميل...</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Course Modal -->
    <div class="modal-overlay" id="course-modal">
      <div class="modal card glass-strong" style="max-width: 600px;">
        <div class="modal-header">
          <h3 style="margin: 0;" id="course-modal-title">إضافة كورس</h3>
          <button class="modal-close" onclick="document.getElementById('course-modal').classList.remove('active')">&times;</button>
        </div>
        <form id="course-form">
          <input type="hidden" id="course-id">
          <div class="form-group">
            <label class="form-label">عنوان الكورس</label>
            <input type="text" id="course-title" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">الوصف</label>
            <textarea id="course-desc" class="form-control" rows="3"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">ماذا ستتعلم في هذا الكورس؟ (اكتب كل نقطة في سطر منفصل)</label>
            <textarea id="course-what-you-will-learn" class="form-control" rows="4" placeholder="مثال:\nأساسيات الإلكترونيات\nاستخدام الأفوميتر"></textarea>
          </div>
          <div class="grid grid-2" style="gap: 15px;">
              <div class="form-group">
                <label class="form-label">الفئة</label>
                <select id="course-category" class="form-control" required>
                  <option value="">اختر الفئة...</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">المستوى</label>
                <select id="course-level" class="form-control">
                  <option value="مبتدئ">مبتدئ</option>
                  <option value="متوسط">متوسط</option>
                  <option value="متقدم">متقدم</option>
                </select>
              </div>
              <div class="form-group">
                <label class="form-label">السعر ($) (اتركه 0 إذا كان مجانياً)</label>
                <input type="number" step="0.01" id="course-price" class="form-control" value="0">
              </div>
          </div>
          <div class="form-group">
            <label class="form-label">الصورة المصغرة (اختيار صورة من جهازك)</label>
            <input type="file" id="course-thumbnail-file" class="form-control" accept="image/*">
            <small class="text-muted">أو استخدم رابط صورة جاهز:</small>
            <input type="text" id="course-thumbnail" class="form-control" style="margin-top: 5px;">
          </div>
          <div class="form-group" style="margin-top: 15px;">
            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                <input type="checkbox" id="course-published"> <strong>نشر الكورس</strong> (سيظهر للطلاب مباشرة)
            </label>
          </div>
          <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
            <button type="button" class="btn btn-outline" onclick="document.getElementById('course-modal').classList.remove('active')">إلغاء</button>
            <button type="submit" class="btn btn-primary" id="btn-save-course">حفظ</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Course Content Management Modal (Sections & Lessons) -->
    <div class="modal-overlay" id="content-modal">
      <div class="modal card glass-strong" style="max-width: 800px; width: 90%; max-height: 90vh; overflow-y: auto;">
        <div class="modal-header">
          <h3 style="margin: 0;" id="content-modal-title">إدارة محتوى الكورس</h3>
          <button class="modal-close" onclick="document.getElementById('content-modal').classList.remove('active')">&times;</button>
        </div>
        <input type="hidden" id="content-course-id">
        
        <div style="margin-bottom: 20px; display: flex; gap: 10px;">
            <input type="text" id="new-section-title" class="form-control" placeholder="اسم القسم الجديد...">
            <button class="btn btn-primary" id="btn-add-section" style="white-space: nowrap;"><i class="fas fa-plus"></i> إضافة قسم</button>
        </div>

        <div id="sections-container" style="display: flex; flex-direction: column; gap: 15px;">
            <div class="text-center text-muted">جاري التحميل...</div>
        </div>
      </div>
    </div>

    <!-- Lesson Modal -->
    <div class="modal-overlay" id="lesson-modal">
      <div class="modal card glass-strong" style="max-width: 500px; z-index: 2000;">
        <div class="modal-header">
          <h3 style="margin: 0;" id="lesson-modal-title">إضافة درس</h3>
          <button class="modal-close" onclick="document.getElementById('lesson-modal').classList.remove('active')">&times;</button>
        </div>
        <form id="lesson-form">
          <input type="hidden" id="lesson-id">
          <input type="hidden" id="lesson-section-id">
          <div class="form-group">
            <label class="form-label">عنوان الدرس</label>
            <input type="text" id="lesson-title-input" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">رابط يوتيوب (Youtube URL)</label>
            <input type="url" id="lesson-youtube" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">المدة بالدقائق</label>
            <input type="number" id="lesson-duration" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">الوصف</label>
            <textarea id="lesson-desc-input" class="form-control" rows="2"></textarea>
          </div>
          <div class="form-group">
            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                <input type="checkbox" id="lesson-free"> درس مجاني (مفتوح للجميع)
            </label>
          </div>
          <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
            <button type="button" class="btn btn-outline" onclick="document.getElementById('lesson-modal').classList.remove('active')">إلغاء</button>
            <button type="submit" class="btn btn-primary" id="btn-save-lesson">حفظ الدرس</button>
          </div>
        </form>
      </div>
    </div>
  `;
};

ManageCourses.setup = async () => {
  let categories = [];
  let coursesList = [];
  
  const loadCategories = async () => {
      try {
          const res = await api.get('/courses/categories');
          if(res && res.data) {
              categories = res.data;
              const select = document.getElementById('course-category');
              if(select) {
                  select.innerHTML = '<option value="">اختر الفئة...</option>' + categories.map(c => `<option value="${c.id}">${c.name_ar}</option>`).join('');
              }
          }
      } catch(e) {}
  };

  const loadCourses = async () => {
      const tbody = document.getElementById('courses-tbody');
      tbody.innerHTML = '<tr><td colspan="6" class="text-center">جاري التحميل...</td></tr>';
      try {
          const res = await api.get('/admin/courses');
          if(res && res.data && res.data.courses) {
              coursesList = res.data.courses;
              if(coursesList.length > 0) {
                  tbody.innerHTML = coursesList.map(c => {
                      let lessonsCount = 0;
                      if(c.sections) c.sections.forEach(s => { if(s.lessons) lessonsCount += s.lessons.length; });
                      
                      const isPublished = c.is_published !== false; // Assuming published by default or explicit field
                      return `
                        <tr>
                          <td style="font-weight: 600;">${c.title}</td>
                          <td>${c.category?.name_ar || 'عام'}</td>
                          <td><span class="badge ${c.level === 'متقدم' ? 'badge-danger' : 'badge-success'}">${c.level || 'مبتدئ'}</span></td>
                          <td>${lessonsCount}</td>
                          <td><span class="badge ${isPublished ? 'badge-primary' : 'badge-warning'}">${isPublished ? 'منشور' : 'مسودة'}</span></td>
                          <td style="display: flex; gap: 5px;">
                            <button class="btn btn-sm btn-outline edit-course-btn" data-id="${c.id}" title="تعديل"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-sm btn-outline content-course-btn" data-id="${c.id}" title="إدارة الدروس"><i class="fas fa-list"></i></button>
                            <button class="btn btn-sm btn-danger delete-course-btn" data-id="${c.id}" title="حذف"><i class="fas fa-trash"></i></button>
                          </td>
                        </tr>
                      `;
                  }).join('');
                  
                  attachCourseEvents();
              } else {
                  tbody.innerHTML = '<tr><td colspan="6" class="text-center">لا توجد كورسات</td></tr>';
              }
          }
      } catch(e) {
          tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger">حدث خطأ في التحميل</td></tr>';
      }
  };

  const attachCourseEvents = () => {
      document.querySelectorAll('.edit-course-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
              const id = parseInt(e.currentTarget.getAttribute('data-id'));
              const c = coursesList.find(course => course.id === id);
              if (!c) return;
              
              document.getElementById('course-modal-title').textContent = 'تعديل كورس';
              document.getElementById('course-id').value = c.id;
              document.getElementById('course-title').value = c.title || '';
              document.getElementById('course-desc').value = c.description || '';
              document.getElementById('course-what-you-will-learn').value = c.what_you_will_learn || '';
              document.getElementById('course-category').value = c.category_id || (c.category ? c.category.id : '');
              document.getElementById('course-level').value = c.level || 'مبتدئ';
              document.getElementById('course-price').value = c.price || 0;
              document.getElementById('course-thumbnail').value = c.thumbnail_url || c.thumbnail || '';
              document.getElementById('course-thumbnail-file').value = '';
              document.getElementById('course-published').checked = c.is_published !== false;
              document.getElementById('course-modal').classList.add('active');
          });
      });
      
      document.querySelectorAll('.delete-course-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
              const id = e.currentTarget.getAttribute('data-id');
              if(confirm('هل أنت متأكد من حذف هذا الكورس؟')) {
                  try {
                      await api.delete('/admin/courses/' + id);
                      if(window.showToast) window.showToast('تم الحذف', 'success');
                      loadCourses();
                  } catch(err) {
                      if(window.showToast) window.showToast(err.error || 'خطأ في الحذف', 'error');
                  }
              }
          });
      });
      
      document.querySelectorAll('.content-course-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
              const id = e.currentTarget.getAttribute('data-id');
              openContentModal(id);
          });
      });
  };

  const addBtn = document.getElementById('btn-open-add-course');
  if(addBtn) {
      addBtn.addEventListener('click', () => {
          document.getElementById('course-form').reset();
          document.getElementById('course-id').value = '';
          document.getElementById('course-what-you-will-learn').value = '';
          document.getElementById('course-thumbnail-file').value = '';
          document.getElementById('course-price').value = 0;
          document.getElementById('course-published').checked = true;
          document.getElementById('course-modal-title').textContent = 'إضافة كورس جديد';
          document.getElementById('course-modal').classList.add('active');
      });
  }

  document.getElementById('course-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const id = document.getElementById('course-id').value;
      const title = document.getElementById('course-title').value;
      const description = document.getElementById('course-desc').value;
      const what_you_will_learn = document.getElementById('course-what-you-will-learn').value;
      const category_id = parseInt(document.getElementById('course-category').value);
      const level = document.getElementById('course-level').value;
      const price = parseFloat(document.getElementById('course-price').value) || 0;
      let thumbnail_url = document.getElementById('course-thumbnail').value;
      const is_published = document.getElementById('course-published').checked;
      
      const adminUser = getUser();
      const instructor_id = adminUser ? adminUser.id : null;
      
      const btn = document.getElementById('btn-save-course');
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

      // Handle Image Upload if selected
      const fileInput = document.getElementById('course-thumbnail-file');
      if (fileInput.files.length > 0) {
          const formData = new FormData();
          formData.append('image', fileInput.files[0]);
          try {
              const res = await api.post('/admin/upload-image', formData);
              if(res && res.data && res.data.url) {
                  thumbnail_url = res.data.url;
              }
          } catch(err) {
              if(window.showToast) window.showToast('فشل رفع الصورة', 'error');
              btn.disabled = false;
              btn.innerHTML = 'حفظ';
              return;
          }
      }
      
      const payload = { title, description, what_you_will_learn, category_id, level, thumbnail_url, is_published, price };
      if(!id) {
          payload.instructor_id = instructor_id;
      }
      
      try {
          if(id) {
              await api.put('/admin/courses/' + id, payload);
              if(window.showToast) window.showToast('تم التعديل بنجاح', 'success');
          } else {
              await api.post('/admin/courses', payload);
              if(window.showToast) window.showToast('تمت الإضافة بنجاح', 'success');
          }
          document.getElementById('course-modal').classList.remove('active');
          loadCourses();
      } catch(err) {
          if(window.showToast) window.showToast(err.error || 'حدث خطأ', 'error');
      } finally {
          btn.disabled = false;
          btn.innerHTML = 'حفظ';
      }
  });

  // --- Content Management (Sections & Lessons) ---
  const openContentModal = async (courseId) => {
      document.getElementById('content-course-id').value = courseId;
      document.getElementById('content-modal').classList.add('active');
      await reloadSections(courseId);
  };
  
  let currentSections = [];

  const reloadSections = async (courseId) => {
      const container = document.getElementById('sections-container');
      container.innerHTML = '<div class="text-center text-muted">جاري التحميل...</div>';
      try {
          const res = await api.get('/admin/courses/' + courseId);
          if(res && res.data && res.data.sections) {
              currentSections = res.data.sections;
              if(res.data.sections.length === 0) {
                  container.innerHTML = '<div class="text-center text-muted">لا توجد أقسام. أضف قسم جديد للبدء.</div>';
                  return;
              }
              
              let html = '';
              res.data.sections.forEach(sec => {
                  html += `
                    <div class="card" style="padding: 15px; border: 1px solid var(--border);">
                        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 10px;">
                            <h4 style="margin: 0;">${sec.title}</h4>
                            <div style="display: flex; gap: 5px;">
                                <button class="btn btn-sm btn-outline btn-add-lesson" data-section-id="${sec.id}"><i class="fas fa-plus"></i> درس</button>
                                <button class="btn btn-sm btn-danger btn-delete-section" data-id="${sec.id}"><i class="fas fa-trash"></i></button>
                            </div>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 10px;">
                  `;
                  if(sec.lessons && sec.lessons.length > 0) {
                      sec.lessons.forEach(l => {
                          html += `
                            <div style="display: flex; justify-content: space-between; background: rgba(0,0,0,0.2); padding: 10px; border-radius: 4px;">
                                <div><i class="fas fa-play-circle text-primary ml-2"></i> ${l.title}</div>
                                <div style="display: flex; gap: 5px;">
                                    <button class="btn btn-sm btn-outline edit-lesson-btn" data-id="${l.id}" data-section-id="${sec.id}"><i class="fas fa-edit"></i></button>
                                    <button class="btn btn-sm btn-danger delete-lesson-btn" data-id="${l.id}"><i class="fas fa-trash"></i></button>
                                </div>
                            </div>
                          `;
                      });
                  } else {
                      html += '<div class="text-muted" style="font-size:0.9rem;">لا توجد دروس في هذا القسم.</div>';
                  }
                  html += `</div></div>`;
              });
              container.innerHTML = html;
              attachContentEvents();
          } else {
              container.innerHTML = '<div class="text-center text-muted">حدث خطأ في تحميل الأقسام.</div>';
          }
      } catch(e) {
          container.innerHTML = '<div class="text-center text-muted">حدث خطأ في تحميل الأقسام.</div>';
      }
  };
  
  document.getElementById('btn-add-section').addEventListener('click', async () => {
      const title = document.getElementById('new-section-title').value;
      const courseId = document.getElementById('content-course-id').value;
      if(!title) return;
      
      try {
          await api.post('/admin/courses/' + courseId + '/sections', { title });
          document.getElementById('new-section-title').value = '';
          await reloadSections(courseId);
          if(window.showToast) window.showToast('تمت إضافة القسم', 'success');
      } catch(err) {
          if(window.showToast) window.showToast(err.error || 'خطأ', 'error');
      }
  });
  
  const attachContentEvents = () => {
      const courseId = document.getElementById('content-course-id').value;
      
      document.querySelectorAll('.btn-delete-section').forEach(btn => {
          btn.addEventListener('click', async (e) => {
              if(!confirm('حذف القسم سيحذف جميع الدروس بداخله. متأكد؟')) return;
              const id = e.currentTarget.getAttribute('data-id');
              try {
                  await api.delete('/admin/sections/' + id);
                  await reloadSections(courseId);
              } catch(err) {
                  if(window.showToast) window.showToast(err.error || 'خطأ', 'error');
              }
          });
      });
      
      document.querySelectorAll('.btn-add-lesson').forEach(btn => {
          btn.addEventListener('click', (e) => {
              const secId = e.currentTarget.getAttribute('data-section-id');
              document.getElementById('lesson-form').reset();
              document.getElementById('lesson-id').value = '';
              document.getElementById('lesson-section-id').value = secId;
              document.getElementById('lesson-modal-title').textContent = 'إضافة درس';
              document.getElementById('lesson-modal').classList.add('active');
          });
      });
      
      document.querySelectorAll('.edit-lesson-btn').forEach(btn => {
          btn.addEventListener('click', (e) => {
              const secId = parseInt(e.currentTarget.getAttribute('data-section-id'));
              const id = parseInt(e.currentTarget.getAttribute('data-id'));
              
              const sec = currentSections.find(s => s.id === secId);
              if (!sec) return;
              
              const l = sec.lessons.find(lesson => lesson.id === id);
              if (!l) return;
              
              document.getElementById('lesson-id').value = l.id;
              document.getElementById('lesson-section-id').value = secId;
              document.getElementById('lesson-title-input').value = l.title || '';
              document.getElementById('lesson-youtube').value = l.youtube_url || l.youtube_embed_url || '';
              document.getElementById('lesson-duration').value = l.duration_minutes || '';
              document.getElementById('lesson-desc-input').value = l.description || '';
              document.getElementById('lesson-free').checked = l.is_free || false;
              
              document.getElementById('lesson-modal-title').textContent = 'تعديل درس';
              document.getElementById('lesson-modal').classList.add('active');
          });
      });
      
      document.querySelectorAll('.delete-lesson-btn').forEach(btn => {
          btn.addEventListener('click', async (e) => {
              if(!confirm('هل أنت متأكد من حذف الدرس؟')) return;
              const id = e.currentTarget.getAttribute('data-id');
              try {
                  await api.delete('/admin/lessons/' + id);
                  await reloadSections(courseId);
              } catch(err) {
                  if(window.showToast) window.showToast(err.error || 'خطأ', 'error');
              }
          });
      });
  };
  
  document.getElementById('lesson-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const courseId = document.getElementById('content-course-id').value;
      const sectionId = document.getElementById('lesson-section-id').value;
      const lessonId = document.getElementById('lesson-id').value;
      
      const payload = {
          title: document.getElementById('lesson-title-input').value,
          youtube_url: document.getElementById('lesson-youtube').value,
          duration_minutes: document.getElementById('lesson-duration').value ? parseInt(document.getElementById('lesson-duration').value) : null,
          description: document.getElementById('lesson-desc-input').value,
          is_free: document.getElementById('lesson-free').checked
      };
      
      const btn = document.getElementById('btn-save-lesson');
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
      
      try {
          if(lessonId) {
              await api.put('/admin/lessons/' + lessonId, payload);
          } else {
              await api.post('/admin/sections/' + sectionId + '/lessons', payload);
          }
          document.getElementById('lesson-modal').classList.remove('active');
          await reloadSections(courseId);
      } catch(err) {
          if(window.showToast) window.showToast(err.error || 'خطأ', 'error');
      } finally {
          btn.disabled = false;
          btn.innerHTML = 'حفظ الدرس';
      }
  });

  loadCategories().then(loadCourses);
};

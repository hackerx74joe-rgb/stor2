import { api } from '../../utils/api.js';

export const ManageUsers = async () => {
  return `
    <div class="admin-layout">
      <!-- Admin Sidebar -->
      <div class="admin-sidebar" id="admin-sidebar">
        <div style="padding: 0 20px 20px; border-bottom: 1px solid var(--border); margin-bottom: 20px;">
          <h3 class="text-gradient" style="margin: 0;">لوحة الإدارة</h3>
        </div>
        
        <nav style="display: flex; flex-direction: column;">
          <a href="#/admin" class="admin-nav-item">
            <i class="fas fa-home"></i> الرئيسية
          </a>
          <a href="#/admin/users" class="admin-nav-item active">
            <i class="fas fa-users"></i> إدارة المستخدمين
          </a>
          <a href="#/admin/courses" class="admin-nav-item">
            <i class="fas fa-video"></i> إدارة الكورسات
          </a>
          <a href="#/" class="admin-nav-item text-muted" style="margin-top: 20px; border-top: 1px solid var(--border); padding-top: 20px;">
            <i class="fas fa-external-link-alt"></i> العودة للموقع
          </a>
        </nav>
      </div>
      
      <!-- Admin Content -->
      <div class="admin-content">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
          <h2>إدارة المستخدمين</h2>
          <button class="btn btn-primary" id="btn-open-add-user">
            <i class="fas fa-plus"></i> إضافة مستخدم
          </button>
        </div>
        
        <div class="card glass" style="margin-bottom: 30px;">
          <div style="display: flex; gap: 15px; margin-bottom: 20px;">
            <div class="input-with-icon" style="flex-grow: 1;">
              <input type="text" id="users-search" class="form-control" placeholder="بحث بالاسم أو البريد...">
              <i class="fas fa-search"></i>
            </div>
          </div>
          
          <div class="table-container">
            <table class="table" id="users-table">
              <thead>
                <tr>
                  <th>الاسم</th>
                  <th>البريد الإلكتروني</th>
                  <th>الدور</th>
                  <th>تاريخ الانضمام</th>
                  <th>إجراءات</th>
                </tr>
              </thead>
              <tbody id="users-tbody">
                <tr><td colspan="5" class="text-center">جاري التحميل...</td></tr>
              </tbody>
            </table>
          </div>
          
          <div id="users-pagination" style="display: flex; justify-content: center; margin-top: 20px; gap: 5px;"></div>
        </div>
      </div>
    </div>

    <!-- User Modal -->
    <div class="modal-overlay" id="user-modal">
      <div class="modal card glass-strong">
        <div class="modal-header">
          <h3 style="margin: 0;" id="user-modal-title">إضافة مستخدم جديد</h3>
          <button class="modal-close" onclick="document.getElementById('user-modal').classList.remove('active')">&times;</button>
        </div>
        <form id="user-form">
          <input type="hidden" id="user-id">
          <div class="form-group">
            <label class="form-label">الاسم الكامل</label>
            <input type="text" id="user-full-name" class="form-control">
          </div>
          <div class="form-group">
            <label class="form-label">اسم المستخدم</label>
            <input type="text" id="user-username" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label">البريد الإلكتروني</label>
            <input type="email" id="user-email" class="form-control" required>
          </div>
          <div class="form-group">
            <label class="form-label" id="password-label" style="display: flex; justify-content: space-between; align-items: center;">
                <span>كلمة المرور</span>
                <button type="button" id="btn-generate-password" class="btn btn-outline" style="padding: 2px 8px; font-size: 0.8rem;"><i class="fas fa-random"></i> توليد تلقائي</button>
            </label>
            <input type="text" id="user-password" class="form-control" autocomplete="new-password">
            <small class="text-muted" id="password-help" style="display:none;">اتركه فارغاً إذا لم ترغب بتغيير كلمة المرور</small>
          </div>
          <div class="form-group">
            <label class="form-label">الدور</label>
            <select id="user-role" class="form-control">
              <option value="student">طالب</option>
              <option value="admin">مدير</option>
            </select>
          </div>
          <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
            <button type="button" class="btn btn-outline" onclick="document.getElementById('user-modal').classList.remove('active')">إلغاء</button>
            <button type="submit" class="btn btn-primary" id="btn-save-user">حفظ</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Enrollment Modal -->
    <div class="modal-overlay" id="enrollment-modal">
      <div class="modal card glass-strong" style="max-width: 600px;">
        <div class="modal-header">
          <h3 style="margin: 0;" id="enrollment-modal-title">إدارة كورسات الطالب</h3>
          <button class="modal-close" onclick="document.getElementById('enrollment-modal').classList.remove('active')">&times;</button>
        </div>
        <input type="hidden" id="enrollment-user-id">
        
        <div style="margin-bottom: 20px; display: flex; gap: 10px;">
            <select id="enrollment-course-select" class="form-control" style="flex-grow: 1;">
                <option value="">اختر كورس لإضافته للطالب...</option>
            </select>
            <button class="btn btn-primary" id="btn-add-enrollment" style="white-space: nowrap;"><i class="fas fa-plus"></i> إضافة</button>
        </div>

        <div id="enrollments-container" style="display: flex; flex-direction: column; gap: 10px;">
            <div class="text-center text-muted">جاري التحميل...</div>
        </div>
      </div>
    </div>
  `;
};

ManageUsers.setup = () => {
  let currentPage = 1;
  let currentSearch = '';
  
  const loadUsers = async () => {
      const tbody = document.getElementById('users-tbody');
      tbody.innerHTML = '<tr><td colspan="5" class="text-center">جاري التحميل...</td></tr>';
      try {
          let qs = '?page=' + currentPage;
          if(currentSearch) qs += '&search=' + currentSearch;
          
          const res = await api.get('/admin/users' + qs);
          if(res && res.data && res.data.users) {
              if(res.data.users.length > 0) {
                  tbody.innerHTML = res.data.users.map(u => `
                    <tr>
                      <td>${u.full_name || u.username}</td>
                      <td>${u.email}</td>
                      <td><span class="badge ${u.role === 'admin' ? 'badge-danger' : 'badge-success'}">${u.role === 'admin' ? 'مدير' : 'طالب'}</span></td>
                      <td dir="ltr" style="text-align: right;">${new Date(u.created_at).toLocaleDateString('ar-EG')}</td>
                      <td>
                        <button class="btn btn-sm btn-outline manage-courses-btn" data-id="${u.id}" data-name="${u.full_name || u.username}" title="إدارة الكورسات"><i class="fas fa-book"></i></button>
                        <button class="btn btn-sm btn-outline edit-user-btn" data-user='${JSON.stringify(u).replace(/'/g, "&#39;")}' title="تعديل"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-sm btn-danger delete-user-btn" data-id="${u.id}" title="حذف"><i class="fas fa-trash"></i></button>
                      </td>
                    </tr>
                  `).join('');
                  
                  document.querySelectorAll('.edit-user-btn').forEach(btn => {
                      btn.addEventListener('click', (e) => {
                          const u = JSON.parse(e.currentTarget.getAttribute('data-user'));
                          document.getElementById('user-modal-title').textContent = 'تعديل مستخدم';
                          document.getElementById('user-id').value = u.id;
                          document.getElementById('user-full-name').value = u.full_name || '';
                          document.getElementById('user-username').value = u.username || '';
                          document.getElementById('user-email').value = u.email || '';
                          document.getElementById('user-role').value = u.role || 'user';
                          document.getElementById('user-password').required = false;
                          document.getElementById('user-password').value = '';
                          document.getElementById('password-help').style.display = 'block';
                          document.getElementById('user-modal').classList.add('active');
                      });
                  });
                  
                  document.querySelectorAll('.delete-user-btn').forEach(btn => {
                      btn.addEventListener('click', async (e) => {
                          const id = e.currentTarget.getAttribute('data-id');
                          if(confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
                              try {
                                  await api.delete('/admin/users/' + id);
                                  if(window.showToast) window.showToast('تم الحذف بنجاح', 'success');
                                  loadUsers();
                              } catch(err) {
                                  if(window.showToast) window.showToast(err.error || 'خطأ في الحذف', 'error');
                              }
                          }
                      });
                  });
                  
                  document.querySelectorAll('.manage-courses-btn').forEach(btn => {
                      btn.addEventListener('click', (e) => {
                          const id = e.currentTarget.getAttribute('data-id');
                          const name = e.currentTarget.getAttribute('data-name');
                          openEnrollmentModal(id, name);
                      });
                  });
              } else {
                  tbody.innerHTML = '<tr><td colspan="5" class="text-center">لا يوجد مستخدمين</td></tr>';
              }
              
              // pagination
              const pages = res.data.pages || 1;
              let pagHtml = '';
              for(let i=1; i<=pages; i++) {
                  pagHtml += `<button class="btn ${i === currentPage ? 'btn-primary' : 'btn-outline'} btn-sm pag-btn" data-page="${i}">${i}</button>`;
              }
              const pagContainer = document.getElementById('users-pagination');
              pagContainer.innerHTML = pagHtml;
              pagContainer.querySelectorAll('.pag-btn').forEach(b => {
                  b.addEventListener('click', (e) => {
                      currentPage = parseInt(e.target.getAttribute('data-page'));
                      loadUsers();
                  });
              });
          }
      } catch(e) {
          tbody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">حدث خطأ</td></tr>';
      }
  };
  
  let searchTimeout;
  const searchInput = document.getElementById('users-search');
  if(searchInput) {
      searchInput.addEventListener('input', (e) => {
          clearTimeout(searchTimeout);
          searchTimeout = setTimeout(() => {
              currentSearch = e.target.value;
              currentPage = 1;
              loadUsers();
          }, 500);
      });
  }
  
  const addBtn = document.getElementById('btn-open-add-user');
  if(addBtn) {
      addBtn.addEventListener('click', () => {
          document.getElementById('user-form').reset();
          document.getElementById('user-id').value = '';
          document.getElementById('user-modal-title').textContent = 'إضافة مستخدم جديد';
          document.getElementById('user-password').required = true;
          document.getElementById('password-help').style.display = 'none';
          document.getElementById('user-modal').classList.add('active');
      });
  }
  
  const genPassBtn = document.getElementById('btn-generate-password');
  if(genPassBtn) {
      genPassBtn.addEventListener('click', () => {
          const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*";
          let password = "";
          for (let i = 0; i < 12; i++) {
              password += chars.charAt(Math.floor(Math.random() * chars.length));
          }
          const passInput = document.getElementById('user-password');
          passInput.value = password;
          passInput.type = 'text'; // temporarily show it
          if(window.showToast) window.showToast('تم توليد كلمة المرور بنجاح', 'success');
      });
  }

  const form = document.getElementById('user-form');
  if(form) {
      form.addEventListener('submit', async (e) => {
          e.preventDefault();
          const id = document.getElementById('user-id').value;
          const full_name = document.getElementById('user-full-name').value;
          const username = document.getElementById('user-username').value;
          const email = document.getElementById('user-email').value;
          const password = document.getElementById('user-password').value;
          const role = document.getElementById('user-role').value;
          
          const payload = { full_name, username, email, role };
          if(password) payload.password = password;
          
          const btn = document.getElementById('btn-save-user');
          btn.disabled = true;
          btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
          
          try {
              if(id) {
                  await api.put('/admin/users/' + id, payload);
                  if(window.showToast) window.showToast('تم التعديل بنجاح', 'success');
              } else {
                  await api.post('/admin/users', payload);
                  if(window.showToast) window.showToast('تمت الإضافة بنجاح', 'success');
              }
              document.getElementById('user-modal').classList.remove('active');
              loadUsers();
          } catch(err) {
              if(window.showToast) window.showToast(err.error || 'حدث خطأ', 'error');
          } finally {
              btn.disabled = false;
              btn.innerHTML = 'حفظ';
          }
      });
  }

  // Enrollments Logic
  let allCourses = [];
  
  const loadAllCourses = async () => {
      try {
          const res = await api.get('/admin/courses');
          if (res && res.data && res.data.courses) {
              allCourses = res.data.courses;
              const select = document.getElementById('enrollment-course-select');
              select.innerHTML = '<option value="">اختر كورس لإضافته للطالب...</option>' + 
                  allCourses.map(c => `<option value="${c.id}">${c.title}</option>`).join('');
          }
      } catch (err) {}
  };

  const openEnrollmentModal = async (userId, userName) => {
      document.getElementById('enrollment-user-id').value = userId;
      document.getElementById('enrollment-modal-title').textContent = 'إدارة كورسات الطالب: ' + userName;
      document.getElementById('enrollment-modal').classList.add('active');
      await reloadEnrollments(userId);
  };

  const reloadEnrollments = async (userId) => {
      const container = document.getElementById('enrollments-container');
      container.innerHTML = '<div class="text-center text-muted">جاري التحميل...</div>';
      try {
          const res = await api.get('/admin/users/' + userId + '/enrollments');
          if (res && res.data && res.data.enrollments) {
              const enrollments = res.data.enrollments;
              if (enrollments.length === 0) {
                  container.innerHTML = '<div class="text-center text-muted">الطالب غير مسجل في أي كورس حالياً.</div>';
              } else {
                  container.innerHTML = enrollments.map(c => `
                      <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px; background: rgba(255,255,255,0.05); border-radius: var(--radius); border: 1px solid var(--border);">
                          <div><strong>${c.course_title}</strong></div>
                          <button class="btn btn-sm btn-danger btn-unenroll" data-user="${userId}" data-course="${c.course_id}"><i class="fas fa-times"></i> إزالة</button>
                      </div>
                  `).join('');
                  
                  document.querySelectorAll('.btn-unenroll').forEach(btn => {
                      btn.addEventListener('click', async (e) => {
                          if (!confirm('هل أنت متأكد من إزالة هذا الكورس من حساب الطالب؟')) return;
                          const uid = e.currentTarget.getAttribute('data-user');
                          const cid = e.currentTarget.getAttribute('data-course');
                          try {
                              await api.delete('/admin/users/' + uid + '/enroll/' + cid);
                              if(window.showToast) window.showToast('تمت الإزالة بنجاح', 'success');
                              reloadEnrollments(uid);
                          } catch (err) {
                              if(window.showToast) window.showToast(err.error || 'خطأ', 'error');
                          }
                      });
                  });
              }
          }
      } catch (err) {
          container.innerHTML = '<div class="text-center text-danger">حدث خطأ في جلب الكورسات</div>';
      }
  };

  const btnGeneratePassword = document.getElementById('btn-generate-password');
  if (btnGeneratePassword) {
      btnGeneratePassword.addEventListener('click', () => {
          const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
          let password = "";
          for (let i = 0; i < 12; i++) {
              password += chars.charAt(Math.floor(Math.random() * chars.length));
          }
          document.getElementById('user-password').value = password;
      });
  }

  document.getElementById('btn-add-enrollment').addEventListener('click', async () => {
      const userId = document.getElementById('enrollment-user-id').value;
      const courseId = document.getElementById('enrollment-course-select').value;
      
      if (!courseId) return;
      
      const btn = document.getElementById('btn-add-enrollment');
      btn.disabled = true;
      btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
      
      try {
          await api.post('/admin/users/' + userId + '/enroll/' + courseId);
          if(window.showToast) window.showToast('تم إضافة الكورس للطالب', 'success');
          document.getElementById('enrollment-course-select').value = '';
          await reloadEnrollments(userId);
      } catch (err) {
          if(window.showToast) window.showToast(err.error || 'خطأ', 'error');
      } finally {
          btn.disabled = false;
          btn.innerHTML = '<i class="fas fa-plus"></i> إضافة';
      }
  });

  loadUsers();
  loadAllCourses();
};

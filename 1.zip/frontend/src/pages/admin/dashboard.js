import { api } from '../../utils/api.js';

export const AdminDashboard = async () => {
  return `
    <div class="admin-layout">
      <!-- Admin Sidebar -->
      <div class="admin-sidebar" id="admin-sidebar">
        <div style="padding: 0 20px 20px; border-bottom: 1px solid var(--border); margin-bottom: 20px;">
          <h3 class="text-gradient" style="margin: 0;">لوحة الإدارة</h3>
        </div>
        
        <nav style="display: flex; flex-direction: column;">
          <a href="#/admin" class="admin-nav-item active">
            <i class="fas fa-home"></i> الرئيسية
          </a>
          <a href="#/admin/users" class="admin-nav-item">
            <i class="fas fa-users"></i> إدارة المستخدمين
          </a>
          <a href="#/admin/courses" class="admin-nav-item">
            <i class="fas fa-video"></i> إدارة الكورسات
          </a>
          <a href="#/" class="admin-nav-item text-muted" style="margin-top: 20px; border-top: 1px solid var(--border); padding-top: 20px;">
            <i class="fas fa-external-link-alt"></i> العودة للموقع
          </a>
        </nav>
      </div>
      
      <!-- Admin Content -->
      <div class="admin-content">
        <h2 style="margin-bottom: 30px;">مرحباً بك في لوحة التحكم</h2>
        
        <div class="grid grid-4 text-center mb-5" style="margin-bottom: 40px;">
          <div class="card glass-strong animate-slide-up">
            <i class="fas fa-users text-primary" style="font-size: 2rem; margin-bottom: 10px;"></i>
            <h3 id="stat-users" class="text-gradient">--</h3>
            <p style="margin: 0;">إجمالي المستخدمين</p>
          </div>
          <div class="card glass-strong animate-slide-up" style="animation-delay: 0.1s;">
            <i class="fas fa-video text-accent" style="font-size: 2rem; margin-bottom: 10px;"></i>
            <h3 id="stat-courses" class="text-accent-gradient">--</h3>
            <p style="margin: 0;">إجمالي الكورسات</p>
          </div>
          <div class="card glass-strong animate-slide-up" style="animation-delay: 0.2s;">
            <i class="fas fa-graduation-cap text-success" style="font-size: 2rem; margin-bottom: 10px;"></i>
            <h3 id="stat-enrollments" style="color: var(--success);">--</h3>
            <p style="margin: 0;">إجمالي التسجيلات</p>
          </div>
          <div class="card glass-strong animate-slide-up" style="animation-delay: 0.3s;">
            <i class="fas fa-book-open text-warning" style="font-size: 2rem; margin-bottom: 10px;"></i>
            <h3 id="stat-lessons" style="color: var(--warning);">--</h3>
            <p style="margin: 0;">إجمالي الدروس</p>
          </div>
        </div>
        
        <div class="grid grid-2">
          <div class="card glass">
            <h3 style="border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 15px;">أحدث التسجيلات</h3>
            <div class="table-container">
              <table class="table">
                <thead>
                  <tr>
                    <th>الطالب</th>
                    <th>الكورس</th>
                    <th>التاريخ</th>
                  </tr>
                </thead>
                <tbody id="recent-enrollments">
                  <tr><td colspan="3" class="text-center">جاري التحميل...</td></tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div class="card glass">
            <h3 style="border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 15px;">إجراءات سريعة</h3>
            <div style="display: flex; flex-direction: column; gap: 15px;">
              <a href="#/admin/courses" class="btn btn-outline" style="justify-content: flex-start;"><i class="fas fa-plus ml-2"></i> إدارة الكورسات</a>
              <a href="#/admin/users" class="btn btn-outline" style="justify-content: flex-start;"><i class="fas fa-user-plus ml-2"></i> إدارة المستخدمين</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
};

AdminDashboard.setup = async () => {
  try {
    const res = await api.get('/admin/stats');
    if(res && res.data) {
        document.getElementById('stat-users').textContent = res.data.total_users || 0;
        document.getElementById('stat-courses').textContent = res.data.total_courses || 0;
        document.getElementById('stat-enrollments').textContent = res.data.total_enrollments || 0;
        document.getElementById('stat-lessons').textContent = res.data.total_lessons || 0;
        
        const tbody = document.getElementById('recent-enrollments');
        if(res.data.recent_enrollments && res.data.recent_enrollments.length > 0) {
            tbody.innerHTML = res.data.recent_enrollments.map(e => `
                <tr>
                    <td>${e.user?.full_name || e.user?.username || 'غير معروف'}</td>
                    <td>${e.course?.title || 'غير معروف'}</td>
                    <td dir="ltr" style="text-align: right;">${new Date(e.enrolled_at).toLocaleDateString('ar-EG')}</td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center">لا توجد تسجيلات حديثة</td></tr>';
        }
    }
  } catch(e) {
      console.error(e);
      document.getElementById('stat-users').textContent = '-';
      document.getElementById('stat-courses').textContent = '-';
      document.getElementById('stat-enrollments').textContent = '-';
      document.getElementById('stat-lessons').textContent = '-';
      document.getElementById('recent-enrollments').innerHTML = '<tr><td colspan="3" class="text-center text-danger">حدث خطأ في تحميل البيانات</td></tr>';
  }
};

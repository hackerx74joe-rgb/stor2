import os
from flask import Flask, jsonify, request
from config import get_config
from models import db, User, Category
from extensions import jwt, limiter, cors
from routes.auth_routes import auth_bp
from routes.courses import courses_bp
from routes.admin import admin_bp

def create_app():
    # Serve static files from the frontend dist folder
    static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../frontend/dist'))
    app = Flask(__name__, static_folder=static_dir, static_url_path='/')
    app.config.from_object(get_config())
    
    # Initialize extensions
    db.init_app(app)
    jwt.init_app(app)
    limiter.init_app(app)
    
    # Set up CORS based on environment
    frontend_url = app.config.get('FRONTEND_URL', '*')
    if app.config.get('DEBUG'):
        cors.init_app(app, resources={r"/api/*": {"origins": "*"}})
    else:
        cors.init_app(app, resources={r"/api/*": {"origins": frontend_url}})
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(courses_bp, url_prefix='/api/courses')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')
    
    # Security Headers Middleware
    @app.after_request
    def add_security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        if not app.config.get('DEBUG'):
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        return response
    @app.route('/uploads/<path:filename>')
    def serve_uploads(filename):
        from flask import send_from_directory
        return send_from_directory(os.path.join(app.root_path, 'uploads'), filename)

    @app.route('/')
    def serve_frontend():
        return app.send_static_file('index.html')

    # Error handlers
    @app.errorhandler(400)
    def bad_request(e):
        return jsonify({'status': 400, 'error': 'Bad Request'}), 400

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({'status': 404, 'error': 'Not Found'}), 404
        
    @app.errorhandler(405)
    def method_not_allowed(e):
        return jsonify({'status': 405, 'error': 'Method Not Allowed'}), 405

    @app.errorhandler(429)
    def ratelimit_handler(e):
        return jsonify({'status': 429, 'error': 'Rate limit exceeded: ' + str(e.description)}), 429

    @app.errorhandler(500)
    def internal_server_error(e):
        return jsonify({'status': 500, 'error': 'Internal Server Error'}), 500

    # JWT Error handlers
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return jsonify({'status': 401, 'error': 'Token has expired'}), 401

    @jwt.invalid_token_loader
    def invalid_token_callback(error):
        return jsonify({'status': 401, 'error': f'Invalid token: {error}'}), 401

    @jwt.unauthorized_loader
    def missing_token_callback(error):
        return jsonify({'status': 401, 'error': 'Request does not contain an access token'}), 401

    @jwt.user_lookup_loader
    def user_lookup_callback(_jwt_header, jwt_data):
        identity = jwt_data["sub"]
        return User.query.filter_by(id=identity).one_or_none()

    @jwt.user_lookup_error_loader
    def custom_user_lookup_error(_jwt_header, _jwt_data):
        return jsonify({'status': 401, 'error': 'المستخدم لم يعد موجوداً أو تم حذفه'}), 401

    return app

def setup_database(app):
    with app.app_context():
        os.makedirs(os.path.join(app.root_path, 'uploads'), exist_ok=True)
        db.create_all()
        
        # Create default admin if not exists
        if not User.query.filter_by(username='admin').first():
            admin_password = os.environ.get('ADMIN_PASSWORD', 'Admin@2024!')
            admin_user = User(
                username='admin',
                email='admin@infotexacademy.com',
                full_name='System Admin',
                role='admin'
            )
            admin_user.set_password(admin_password)
            db.session.add(admin_user)
            db.session.commit()
            print("Default admin created.")

        # Create default categories if none exist
        if Category.query.count() == 0:
            default_categories = [
                {'name': 'Motherboard Repair', 'name_ar': 'صيانة اللوحة الأم'},
                {'name': 'Screen Repair', 'name_ar': 'صيانة الشاشات'},
                {'name': 'Software Repair', 'name_ar': 'صيانة البرمجيات'},
                {'name': 'Hardware Repair', 'name_ar': 'صيانة الهاردوير'},
                {'name': 'Tools & Measurement', 'name_ar': 'أدوات وأجهزة القياس'},
                {'name': 'Advanced Courses', 'name_ar': 'كورسات متقدمة'}
            ]
            for cat_data in default_categories:
                db.session.add(Category(name=cat_data['name'], name_ar=cat_data['name_ar']))
            db.session.commit()
            print("Default categories created.")

app = create_app()
setup_database(app)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)

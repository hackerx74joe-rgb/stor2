from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from models import db, User
from extensions import limiter

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
@limiter.limit("5 per minute; 20 per hour")
def login():
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'status': 400, 'error': 'Username and password are required'}), 400
    
    user = User.query.filter_by(username=data['username']).first()
    if user and user.check_password(data['password']):
        if not user.is_active:
            return jsonify({'status': 403, 'error': 'Account is disabled'}), 403
        access_token = create_access_token(identity=str(user.id))
        
        return jsonify({
            'status': 200,
            'message': 'Login successful',
            'data': {
                'token': access_token,
                'user': user.to_dict()
            }
        }), 200
        
    return jsonify({'status': 401, 'error': 'Invalid username or password'}), 401

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def me():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user:
        return jsonify({'status': 404, 'error': 'User not found'}), 404
        
    return jsonify({
        'status': 200,
        'message': 'User profile retrieved successfully',
        'data': user.to_dict()
    }), 200

@auth_bp.route('/profile', methods=['PUT'])
@jwt_required()
def profile():
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    if not user:
        return jsonify({'status': 404, 'error': 'User not found'}), 404
        
    data = request.get_json()
    if not data:
        return jsonify({'status': 400, 'error': 'Invalid JSON data'}), 400
    
    if 'full_name' in data:
        user.full_name = data['full_name']
    
    if 'email' in data:
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user and existing_user.id != user_id:
            return jsonify({'status': 400, 'error': 'Email is already taken'}), 400
        user.email = data['email']
        
    if 'avatar_url' in data:
        user.avatar_url = data['avatar_url']
        
    if 'password' in data and 'current_password' in data:
        if not user.check_password(data['current_password']):
            return jsonify({'status': 401, 'error': 'Invalid current password'}), 401
        
        if len(data['password']) < 6:
            return jsonify({'status': 400, 'error': 'New password must be at least 6 characters'}), 400
            
        user.set_password(data['password'])
        
    db.session.commit()
    
    return jsonify({
        'status': 200,
        'message': 'Profile updated successfully',
        'data': user.to_dict()
    }), 200

@auth_bp.route('/logout', methods=['POST'])
def logout():
    return jsonify({
        'status': 200,
        'message': 'Logged out successfully'
    }), 200

from flask import Blueprint, request, jsonify, current_app
from flask_jwt_extended import jwt_required
from werkzeug.utils import secure_filename
import os
import uuid
from models import db, User, Course, Section, Lesson, Category, Enrollment, CourseReview
from utils.decorators import admin_required

admin_bp = Blueprint('admin', __name__)

# User Management
@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@admin_required()
def get_users():
    search = request.args.get('search', type=str)
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)

    query = User.query
    if search:
        query = query.filter((User.username.ilike(f'%{search}%')) | (User.email.ilike(f'%{search}%')))
        
    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'status': 200,
        'message': 'Users retrieved successfully',
        'data': {
            'users': [user.to_dict() for user in pagination.items],
            'total': pagination.total,
            'pages': pagination.pages,
            'current_page': page
        }
    }), 200

@admin_bp.route('/users', methods=['POST'])
@jwt_required()
@admin_required()
def create_user():
    data = request.get_json()
    if not data or not all(k in data for k in ['username', 'email', 'password', 'full_name']):
        return jsonify({'status': 400, 'error': 'جميع الحقول مطلوبة'}), 400
        
    if len(data['password']) < 6:
        return jsonify({'status': 400, 'error': 'كلمة المرور يجب أن تكون 6 أحرف على الأقل'}), 400
        
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'status': 400, 'error': 'اسم المستخدم موجود بالفعل'}), 400
        
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'status': 400, 'error': 'البريد الإلكتروني مستخدم بالفعل'}), 400
        
    user = User(
        username=data['username'],
        email=data['email'],
        full_name=data['full_name'],
        role=data.get('role', 'student'),
        is_active=data.get('is_active', True)
    )
    user.set_password(data['password'])
    db.session.add(user)
    db.session.commit()
    
    return jsonify({'status': 201, 'message': 'User created successfully', 'data': user.to_dict()}), 201

@admin_bp.route('/users/<int:user_id>', methods=['PUT', 'DELETE'])
@jwt_required()
@admin_required()
def modify_user(user_id):
    user = User.query.get(user_id)
    if not user:
        return jsonify({'status': 404, 'error': 'User not found'}), 404
        
    if request.method == 'DELETE':
        db.session.delete(user)
        db.session.commit()
        return jsonify({'status': 200, 'message': 'User deleted successfully'}), 200
        
    data = request.get_json()
    if 'full_name' in data:
        user.full_name = data['full_name']
    if 'role' in data:
        user.role = data['role']
    if 'is_active' in data:
        user.is_active = data['is_active']
    if 'password' in data and len(data['password']) >= 6:
        user.set_password(data['password'])
        
    db.session.commit()
    return jsonify({'status': 200, 'message': 'User updated successfully', 'data': user.to_dict()}), 200

@admin_bp.route('/users/<int:user_id>/enrollments', methods=['GET'])
@jwt_required()
@admin_required()
def get_user_enrollments(user_id):
    user = User.query.get(user_id)
    if not user: return jsonify({'status': 404, 'error': 'User not found'}), 404
    
    enrollments = Enrollment.query.filter_by(user_id=user_id).all()
    courses = []
    for en in enrollments:
        if en.course:
            courses.append({
                'course_id': en.course.id,
                'course_title': en.course.title,
                'enrolled_at': en.enrolled_at.isoformat() if en.enrolled_at else None
            })
            
    return jsonify({'status': 200, 'message': 'Enrollments retrieved', 'data': {'enrollments': courses}}), 200

@admin_bp.route('/users/<int:user_id>/enroll/<int:course_id>', methods=['POST', 'DELETE'])
@jwt_required()
@admin_required()
def admin_manage_enroll(user_id, course_id):
    user = User.query.get(user_id)
    course = Course.query.get(course_id)
    if not user or not course:
        return jsonify({'status': 404, 'error': 'User or Course not found'}), 404
        
    existing = Enrollment.query.filter_by(user_id=user_id, course_id=course_id).first()
    
    if request.method == 'DELETE':
        if not existing:
            return jsonify({'status': 404, 'error': 'Enrollment not found'}), 404
        db.session.delete(existing)
        db.session.commit()
        return jsonify({'status': 200, 'message': 'User unenrolled successfully'}), 200
        
    if existing:
        return jsonify({'status': 400, 'error': 'User already enrolled'}), 400
        
    enrollment = Enrollment(user_id=user_id, course_id=course_id)
    db.session.add(enrollment)
    db.session.commit()
    return jsonify({'status': 201, 'message': 'User enrolled successfully'}), 201

# Helper to check allowed extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@admin_bp.route('/upload-image', methods=['POST'])
@jwt_required()
@admin_required()
def upload_image():
    if 'image' not in request.files:
        return jsonify({'status': 400, 'error': 'No image file provided'}), 400
        
    file = request.files['image']
    if file.filename == '':
        return jsonify({'status': 400, 'error': 'No selected file'}), 400
        
    if file and allowed_file(file.filename):
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = f"{uuid.uuid4().hex}.{ext}"
        upload_folder = os.path.join(current_app.root_path, 'uploads')
        os.makedirs(upload_folder, exist_ok=True)
        file.save(os.path.join(upload_folder, filename))
        
        # Return the URL for the frontend
        file_url = f"{current_app.config.get('BACKEND_URL', 'http://localhost:5000')}/uploads/{filename}"
        return jsonify({'status': 200, 'message': 'File uploaded successfully', 'data': {'url': file_url}}), 200
        
    return jsonify({'status': 400, 'error': 'Invalid file type'}), 400

# Course Management
@admin_bp.route('/courses', methods=['GET'])
@jwt_required()
@admin_required()
def get_all_courses():
    courses = Course.query.order_by(Course.created_at.desc()).all()
    return jsonify({
        'status': 200,
        'message': 'All courses retrieved successfully',
        'data': {
            'courses': [c.to_dict() for c in courses]
        }
    }), 200

@admin_bp.route('/courses/<int:course_id>', methods=['GET'])
@jwt_required()
@admin_required()
def get_admin_course(course_id):
    course = Course.query.get(course_id)
    if not course:
        return jsonify({'status': 404, 'error': 'Course not found'}), 404
        
    return jsonify({
        'status': 200,
        'message': 'Course retrieved successfully',
        'data': course.to_dict_full()
    }), 200

@admin_bp.route('/courses', methods=['POST'])
@jwt_required()
@admin_required()
def create_course():
    data = request.get_json()
    if not data or not all(k in data for k in ['title', 'description', 'category_id', 'instructor_id']):
        return jsonify({'status': 400, 'error': 'Missing required fields'}), 400
        
    course = Course(
        title=data['title'],
        description=data['description'],
        thumbnail_url=data.get('thumbnail_url'),
        category_id=data['category_id'],
        level=data.get('level', 'beginner'),
        instructor_id=data['instructor_id'],
        is_published=data.get('is_published', False),
        price=data.get('price', 0.0),
        what_you_will_learn=data.get('what_you_will_learn')
    )
    db.session.add(course)
    db.session.commit()
    return jsonify({'status': 201, 'message': 'Course created successfully', 'data': course.to_dict()}), 201

@admin_bp.route('/courses/<int:course_id>', methods=['PUT', 'DELETE'])
@jwt_required()
@admin_required()
def modify_course(course_id):
    course = Course.query.get(course_id)
    if not course:
        return jsonify({'status': 404, 'error': 'Course not found'}), 404
        
    if request.method == 'DELETE':
        db.session.delete(course)
        db.session.commit()
        return jsonify({'status': 200, 'message': 'Course deleted successfully'}), 200
        
    data = request.get_json()
    for field in ['title', 'description', 'thumbnail_url', 'category_id', 'level', 'instructor_id', 'is_published', 'price']:
        if field in data:
            setattr(course, field, data[field])
            
    db.session.commit()
    return jsonify({'status': 200, 'message': 'Course updated successfully', 'data': course.to_dict()}), 200

@admin_bp.route('/courses/<int:course_id>/publish', methods=['PUT'])
@jwt_required()
@admin_required()
def toggle_publish_course(course_id):
    course = Course.query.get(course_id)
    if not course:
        return jsonify({'status': 404, 'error': 'Course not found'}), 404
        
    course.is_published = not course.is_published
    db.session.commit()
    return jsonify({'status': 200, 'message': f"Course {'published' if course.is_published else 'unpublished'} successfully"}), 200

# Section Management
@admin_bp.route('/courses/<int:course_id>/sections', methods=['POST'])
@jwt_required()
@admin_required()
def create_section(course_id):
    data = request.get_json()
    if not data or not data.get('title'):
        return jsonify({'status': 400, 'error': 'Title is required'}), 400
        
    # Get max order
    max_order = db.session.query(db.func.max(Section.order)).filter_by(course_id=course_id).scalar() or 0
    
    section = Section(
        course_id=course_id,
        title=data['title'],
        order=data.get('order', max_order + 1)
    )
    db.session.add(section)
    db.session.commit()
    return jsonify({'status': 201, 'message': 'Section created successfully', 'data': section.to_dict()}), 201

@admin_bp.route('/sections/<int:section_id>', methods=['PUT', 'DELETE'])
@jwt_required()
@admin_required()
def modify_section(section_id):
    section = Section.query.get(section_id)
    if not section:
        return jsonify({'status': 404, 'error': 'Section not found'}), 404
        
    if request.method == 'DELETE':
        db.session.delete(section)
        db.session.commit()
        return jsonify({'status': 200, 'message': 'Section deleted successfully'}), 200
        
    data = request.get_json()
    if 'title' in data:
        section.title = data['title']
    if 'order' in data:
        section.order = data['order']
        
    db.session.commit()
    return jsonify({'status': 200, 'message': 'Section updated successfully', 'data': section.to_dict()}), 200

@admin_bp.route('/sections/reorder', methods=['PUT'])
@jwt_required()
@admin_required()
def reorder_sections():
    data = request.get_json() # expects [{'id': 1, 'order': 1}, ...]
    if not data or not isinstance(data, list):
        return jsonify({'status': 400, 'error': 'Invalid data format'}), 400
        
    for item in data:
        section = Section.query.get(item.get('id'))
        if section and 'order' in item:
            section.order = item['order']
            
    db.session.commit()
    return jsonify({'status': 200, 'message': 'Sections reordered successfully'}), 200

# Lesson Management
@admin_bp.route('/sections/<int:section_id>/lessons', methods=['POST'])
@jwt_required()
@admin_required()
def create_lesson(section_id):
    data = request.get_json()
    if not data or not data.get('title'):
        return jsonify({'status': 400, 'error': 'Title is required'}), 400
        
    max_order = db.session.query(db.func.max(Lesson.order)).filter_by(section_id=section_id).scalar() or 0
    
    lesson = Lesson(
        section_id=section_id,
        title=data['title'],
        description=data.get('description'),
        youtube_url=data.get('youtube_url'),
        duration_minutes=data.get('duration_minutes', 0),
        order=data.get('order', max_order + 1),
        is_free=data.get('is_free', False)
    )
    db.session.add(lesson)
    db.session.commit()
    return jsonify({'status': 201, 'message': 'Lesson created successfully', 'data': lesson.to_dict()}), 201

@admin_bp.route('/lessons/<int:lesson_id>', methods=['PUT', 'DELETE'])
@jwt_required()
@admin_required()
def modify_lesson(lesson_id):
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({'status': 404, 'error': 'Lesson not found'}), 404
        
    if request.method == 'DELETE':
        db.session.delete(lesson)
        db.session.commit()
        return jsonify({'status': 200, 'message': 'Lesson deleted successfully'}), 200
        
    data = request.get_json()
    for field in ['title', 'description', 'youtube_url', 'duration_minutes', 'order', 'is_free', 'section_id']:
        if field in data:
            setattr(lesson, field, data[field])
            
    db.session.commit()
    return jsonify({'status': 200, 'message': 'Lesson updated successfully', 'data': lesson.to_dict()}), 200

@admin_bp.route('/lessons/reorder', methods=['PUT'])
@jwt_required()
@admin_required()
def reorder_lessons():
    data = request.get_json()
    if not data or not isinstance(data, list):
        return jsonify({'status': 400, 'error': 'Invalid data format'}), 400
        
    for item in data:
        lesson = Lesson.query.get(item.get('id'))
        if lesson and 'order' in item:
            lesson.order = item['order']
            
    db.session.commit()
    return jsonify({'status': 200, 'message': 'Lessons reordered successfully'}), 200

# Category Management
@admin_bp.route('/categories', methods=['POST'])
@jwt_required()
@admin_required()
def create_category():
    data = request.get_json()
    if not data or not data.get('name') or not data.get('name_ar'):
        return jsonify({'status': 400, 'error': 'Name and name_ar are required'}), 400
        
    category = Category(
        name=data['name'],
        name_ar=data['name_ar'],
        icon=data.get('icon'),
        description=data.get('description')
    )
    db.session.add(category)
    db.session.commit()
    return jsonify({'status': 201, 'message': 'Category created successfully', 'data': category.to_dict()}), 201

@admin_bp.route('/categories/<int:category_id>', methods=['PUT', 'DELETE'])
@jwt_required()
@admin_required()
def modify_category(category_id):
    category = Category.query.get(category_id)
    if not category:
        return jsonify({'status': 404, 'error': 'Category not found'}), 404
        
    if request.method == 'DELETE':
        if Course.query.filter_by(category_id=category_id).first():
            return jsonify({'status': 400, 'error': 'Cannot delete category with associated courses'}), 400
        db.session.delete(category)
        db.session.commit()
        return jsonify({'status': 200, 'message': 'Category deleted successfully'}), 200
        
    data = request.get_json()
    for field in ['name', 'name_ar', 'icon', 'description']:
        if field in data:
            setattr(category, field, data[field])
            
    db.session.commit()
    return jsonify({'status': 200, 'message': 'Category updated successfully', 'data': category.to_dict()}), 200

# Dashboard
@admin_bp.route('/stats', methods=['GET'])
@jwt_required()
@admin_required()
def get_stats():
    total_users = User.query.count()
    total_courses = Course.query.count()
    total_enrollments = Enrollment.query.count()
    total_lessons = Lesson.query.count()
    
    recent_enrollments = Enrollment.query.order_by(Enrollment.enrolled_at.desc()).limit(5).all()
    
    return jsonify({
        'status': 200,
        'message': 'Stats retrieved successfully',
        'data': {
            'total_users': total_users,
            'total_courses': total_courses,
            'total_enrollments': total_enrollments,
            'total_lessons': total_lessons,
            'recent_enrollments': [
                {
                    'id': en.id,
                    'user': en.user.username,
                    'course': en.course.title,
                    'enrolled_at': en.enrolled_at.isoformat() if en.enrolled_at else None
                }
                for en in recent_enrollments
            ]
        }
    }), 200

@admin_bp.route('/reviews/<int:review_id>', methods=['DELETE'])
@jwt_required()
@admin_required()
def delete_review(review_id):
    review = CourseReview.query.get(review_id)
    if not review:
        return jsonify({'status': 404, 'error': 'Review not found'}), 404
        
    db.session.delete(review)
    db.session.commit()
    
    return jsonify({'status': 200, 'message': 'Review deleted successfully'}), 200

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from models import db, Course, Category, Enrollment, Lesson, LessonProgress, CourseReview
from datetime import datetime, timezone

courses_bp = Blueprint('courses', __name__)

@courses_bp.route('/', methods=['GET'])
def get_courses():
    category_id = request.args.get('category', type=int)
    level = request.args.get('level', type=str)
    search = request.args.get('search', type=str)
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)

    query = Course.query.filter_by(is_published=True)

    if category_id:
        query = query.filter_by(category_id=category_id)
    if level:
        query = query.filter_by(level=level)
    if search:
        query = query.filter(Course.title.ilike(f'%{search}%'))

    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    return jsonify({
        'status': 200,
        'message': 'Courses retrieved successfully',
        'data': {
            'courses': [course.to_dict() for course in pagination.items],
            'total': pagination.total,
            'pages': pagination.pages,
            'current_page': page
        }
    }), 200

@courses_bp.route('/featured-reviews', methods=['GET'])
def get_featured_reviews():
    # Get recent 5-star reviews, max 6
    reviews = CourseReview.query.filter_by(rating=5).order_by(CourseReview.created_at.desc()).limit(6).all()
    
    return jsonify({
        'status': 200,
        'data': [r.to_dict() for r in reviews]
    }), 200

@courses_bp.route('/<int:course_id>', methods=['GET'])
@jwt_required(optional=True)
def get_course(course_id):
    course = Course.query.get(course_id)
    if not course or not course.is_published:
        return jsonify({'status': 404, 'error': 'Course not found'}), 404
        
    user_id = get_jwt_identity()
    is_admin = False
    is_enrolled = False
    
    if user_id:
        from models import User
        user = User.query.get(user_id)
        if user and user.role == 'admin':
            is_admin = True
        elif Enrollment.query.filter_by(user_id=user_id, course_id=course_id).first():
            is_enrolled = True
            
    data = course.to_dict_full()
    
    # Hide youtube_url if not enrolled and not admin
    if not (is_admin or is_enrolled):
        for section in data.get('sections', []):
            for lesson in section.get('lessons', []):
                if not lesson.get('is_free', False):
                    lesson['youtube_url'] = None
                    lesson['youtube_embed_url'] = None
                    
    return jsonify({
        'status': 200,
        'message': 'Course retrieved successfully',
        'data': data
    }), 200

@courses_bp.route('/categories', methods=['GET'])
def get_categories():
    categories = Category.query.all()
    return jsonify({
        'status': 200,
        'message': 'Categories retrieved successfully',
        'data': [category.to_dict() for category in categories]
    }), 200



@courses_bp.route('/my-courses', methods=['GET'])
@jwt_required()
def get_my_courses():
    user_id = get_jwt_identity()
    enrollments = Enrollment.query.filter_by(user_id=user_id).all()
    
    courses = []
    for en in enrollments:
        course = Course.query.get(en.course_id)
        if course:
            courses.append(course.to_dict())
            
    return jsonify({
        'status': 200,
        'message': 'Enrolled courses retrieved successfully',
        'data': courses
    }), 200

@courses_bp.route('/<int:course_id>/progress', methods=['GET'])
@jwt_required()
def course_progress(course_id):
    user_id = get_jwt_identity()
    
    enrollment = Enrollment.query.filter_by(user_id=user_id, course_id=course_id).first()
    if not enrollment:
        return jsonify({'status': 403, 'error': 'Not enrolled in this course'}), 403
        
    course = Course.query.get(course_id)
    all_lessons = []
    for section in course.sections:
        for lesson in section.lessons:
            all_lessons.append(lesson.id)
            
    total_lessons = len(all_lessons)
    if total_lessons == 0:
        return jsonify({
            'status': 200,
            'message': 'Progress retrieved successfully',
            'data': {'progress_percentage': 0, 'completed_lessons': 0, 'total_lessons': 0}
        }), 200
        
    completed_lessons = LessonProgress.query.filter(
        LessonProgress.user_id == user_id,
        LessonProgress.lesson_id.in_(all_lessons),
        LessonProgress.is_completed == True
    ).count()
    
    progress_percentage = (completed_lessons / total_lessons) * 100
    
    return jsonify({
        'status': 200,
        'message': 'Progress retrieved successfully',
        'data': {
            'progress_percentage': round(progress_percentage, 2),
            'completed_lessons': completed_lessons,
            'total_lessons': total_lessons
        }
    }), 200

@courses_bp.route('/lessons/<int:lesson_id>/complete', methods=['PUT'])
@jwt_required()
def complete_lesson(lesson_id):
    user_id = get_jwt_identity()
    
    lesson = Lesson.query.get(lesson_id)
    if not lesson:
        return jsonify({'status': 404, 'error': 'Lesson not found'}), 404
        
    enrollment = Enrollment.query.filter_by(user_id=user_id, course_id=lesson.section.course_id).first()
    
    from models import User
    user = User.query.get(user_id)
    is_admin = user and user.role == 'admin'
    
    if not enrollment and not is_admin:
        return jsonify({'status': 403, 'error': 'Not enrolled in this course'}), 403
        
    progress = LessonProgress.query.filter_by(user_id=user_id, lesson_id=lesson_id).first()
    if not progress:
        progress = LessonProgress(user_id=user_id, lesson_id=lesson_id, is_completed=True, completed_at=datetime.now(timezone.utc))
        db.session.add(progress)
    else:
        progress.is_completed = True
        progress.completed_at = datetime.now(timezone.utc)
        
    db.session.commit()
    
    return jsonify({
        'status': 200,
        'message': 'Lesson marked as completed',
        'data': progress.to_dict()
    }), 200

@courses_bp.route('/<int:course_id>/reviews', methods=['GET'])
def get_course_reviews(course_id):
    reviews = CourseReview.query.filter_by(course_id=course_id).order_by(CourseReview.created_at.desc()).all()
    return jsonify({'status': 200, 'data': [r.to_dict() for r in reviews]}), 200

@courses_bp.route('/<int:course_id>/reviews', methods=['POST'])
@jwt_required()
def add_course_review(course_id):
    user_id = get_jwt_identity()
    data = request.get_json()
    rating = data.get('rating')
    comment = data.get('comment', '')
    if not rating or not isinstance(rating, int) or rating < 1 or rating > 5:
        return jsonify({'status': 400, 'error': 'Invalid rating'}), 400
    # Check if enrolled
    enrollment = Enrollment.query.filter_by(user_id=user_id, course_id=course_id).first()
    if not enrollment:
        return jsonify({'status': 403, 'error': 'You must be enrolled to review this course'}), 403
    existing = CourseReview.query.filter_by(user_id=user_id, course_id=course_id).first()
    if existing:
        return jsonify({'status': 400, 'error': 'You already reviewed this course'}), 400
    # Basic sanitization (prevent simple XSS)
    import html
    comment = html.escape(comment)
    review = CourseReview(user_id=user_id, course_id=course_id, rating=rating, comment=comment)
    db.session.add(review)
    db.session.commit()
    return jsonify({'status': 201, 'message': 'Review added', 'data': review.to_dict()}), 201

